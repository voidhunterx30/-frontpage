import { create } from "zustand";
import type { Feed, FeedItem, Category, UserPreferences } from "@/lib/types";

interface AppState {
  feeds: Feed[];
  items: FeedItem[];
  categories: Category[];
  preferences: UserPreferences;
  selectedFeedId: string | null;
  selectedCategoryId: string | null;
  searchQuery: string;
  isLoading: boolean;
  sidebarOpen: boolean;
  isGuest: boolean;
  currentView: "feed" | "bookmarks" | "search" | "analytics" | "settings" | "digest";

  setFeeds: (feeds: Feed[]) => void;
  setItems: (items: FeedItem[]) => void;
  addItem: (item: FeedItem) => void;
  addItems: (items: FeedItem[]) => void;
  updateItem: (id: string, updates: Partial<FeedItem>) => void;
  setCategories: (categories: Category[]) => void;
  addCategory: (category: Category) => void;
  updateCategory: (id: string, updates: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  setPreferences: (prefs: Partial<UserPreferences>) => void;
  setSelectedFeed: (id: string | null) => void;
  setSelectedCategory: (id: string | null) => void;
  setSearchQuery: (query: string) => void;
  setLoading: (loading: boolean) => void;
  setSidebarOpen: (open: boolean) => void;
  setIsGuest: (guest: boolean) => void;
  setCurrentView: (view: AppState["currentView"]) => void;
  markAsRead: (itemId: string) => void;
  markAllAsRead: (feedId?: string, categoryId?: string) => void;
  toggleBookmark: (itemId: string) => void;
  getFilteredItems: () => FeedItem[];
  getUnreadCount: (feedId?: string, categoryId?: string) => number;
}

export const useAppStore = create<AppState>((set, get) => ({
  feeds: [],
  items: [],
  categories: [],
  preferences: {
    layout: "list",
    theme: "system",
    refresh_interval: 30,
    show_read_items: true,
  },
  selectedFeedId: null,
  selectedCategoryId: null,
  searchQuery: "",
  isLoading: false,
  sidebarOpen: true,
  isGuest: false,
  currentView: "feed",

  setFeeds: (feeds) => set({ feeds }),
  setItems: (items) => set({ items }),
  addItem: (item) => set((state) => ({ items: [item, ...state.items] })),
  addItems: (newItems) => set((state) => {
    const existingIds = new Set(state.items.map((i) => i.id));
    const unique = newItems.filter((i) => !existingIds.has(i.id));
    return { items: [...unique, ...state.items] };
  }),
  updateItem: (id, updates) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.id === id ? { ...item, ...updates } : item
      ),
    })),
  setCategories: (categories) => set({ categories }),
  addCategory: (category) =>
    set((state) => ({ categories: [...state.categories, category] })),
  updateCategory: (id, updates) =>
    set((state) => ({
      categories: state.categories.map((c) =>
        c.id === id ? { ...c, ...updates } : c
      ),
    })),
  deleteCategory: (id) =>
    set((state) => ({
      categories: state.categories.filter((c) => c.id !== id),
    })),
  setPreferences: (prefs) =>
    set((state) => ({
      preferences: { ...state.preferences, ...prefs },
    })),
  setSelectedFeed: (id) => set({ selectedFeedId: id, currentView: "feed" }),
  setSelectedCategory: (id) => set({ selectedCategoryId: id, currentView: "feed" }),
  setSearchQuery: (query) => set({ searchQuery: query }),
  setLoading: (loading) => set({ isLoading: loading }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setIsGuest: (guest) => set({ isGuest: guest }),
  setCurrentView: (view) => set({ currentView: view }),

  markAsRead: (itemId) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.id === itemId ? { ...item, is_read: true } : item
      ),
    })),

  markAllAsRead: (feedId, categoryId) =>
    set((state) => {
      let filtered = state.items.filter((item) => !item.is_read);
      if (feedId) {
        filtered = filtered.filter((item) => item.feed_id === feedId);
      }
      if (categoryId) {
        const feedIds = state.feeds
          .filter((f) => f.category_id === categoryId)
          .map((f) => f.id);
        filtered = filtered.filter((item) => feedIds.includes(item.feed_id));
      }
      const readIds = new Set(filtered.map((i) => i.id));
      return {
        items: state.items.map((item) =>
          readIds.has(item.id) ? { ...item, is_read: true } : item
        ),
      };
    }),

  toggleBookmark: (itemId) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.id === itemId
          ? { ...item, is_bookmarked: !item.is_bookmarked }
          : item
      ),
    })),

  getFilteredItems: () => {
    const state = get();
    let filtered = [...state.items];

    if (state.selectedFeedId) {
      filtered = filtered.filter((item) => item.feed_id === state.selectedFeedId);
    }

    if (state.selectedCategoryId) {
      const feedIds = state.feeds
        .filter((f) => f.category_id === state.selectedCategoryId)
        .map((f) => f.id);
      filtered = filtered.filter((item) => feedIds.includes(item.feed_id));
    }

    if (!state.preferences.show_read_items) {
      filtered = filtered.filter((item) => !item.is_read);
    }

    return filtered.sort(
      (a, b) =>
        new Date(b.published_at).getTime() - new Date(a.published_at).getTime()
    );
  },

  getUnreadCount: (feedId, categoryId) => {
    const state = get();
    let items = state.items.filter((item) => !item.is_read);
    if (feedId) {
      items = items.filter((item) => item.feed_id === feedId);
    }
    if (categoryId) {
      const feedIds = state.feeds
        .filter((f) => f.category_id === categoryId)
        .map((f) => f.id);
      items = items.filter((item) => feedIds.includes(item.feed_id));
    }
    return items.length;
  },
}));
