"use client";

import { useState, useEffect, useCallback } from "react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  ArrowLeft,
  ExternalLink,
  Bookmark,
  BookmarkCheck,
  ChevronLeft,
  ChevronRight,
  Clock,
  User,
  Rss,
} from "lucide-react";
import { cn, formatDate, stripHtml, getFaviconUrl } from "@/lib/utils";
import type { FeedItem as FeedItemType } from "@/lib/types";

export function ReaderView({ itemId }: { itemId: string }) {
  const { items, feeds, markAsRead, toggleBookmark, setCurrentView } =
    useAppStore();
  const [fontSize, setFontSize] = useState(18);

  const item = items.find((i) => i.id === itemId);
  const feed = feeds.find((f) => f.id === item?.feed_id);

  const currentIndex = items.findIndex((i) => i.id === itemId);
  const prevItem = currentIndex > 0 ? items[currentIndex - 1] : null;
  const nextItem = currentIndex < items.length - 1 ? items[currentIndex + 1] : null;

  useEffect(() => {
    if (item && !item.is_read) {
      markAsRead(item.id);
    }
  }, [item?.id]);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" && prevItem) {
        // Navigate to prev
      }
      if (e.key === "ArrowRight" && nextItem) {
        // Navigate to next
      }
    },
    [prevItem, nextItem]
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  if (!item) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-text-secondary">Article not found</p>
      </div>
    );
  }

  const content = item.content || item.description || "";
  const plainContent = stripHtml(content);

  return (
    <div className="h-full flex flex-col bg-bg-primary">
      <header className="h-14 border-b border-border flex items-center gap-2 px-4 shrink-0">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCurrentView("feed")}
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>

        <div className="flex-1" />

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleBookmark(item.id)}
          >
            {item.is_bookmarked ? (
              <BookmarkCheck className="h-4 w-4 text-accent" />
            ) : (
              <Bookmark className="h-4 w-4" />
            )}
          </Button>

          <a
            href={item.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button variant="ghost" size="sm">
              <ExternalLink className="h-4 w-4" />
              Original
            </Button>
          </a>

          <div className="h-6 w-px bg-border mx-1" />

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setFontSize((s) => Math.max(14, s - 2))}
            disabled={fontSize <= 14}
          >
            A-
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setFontSize((s) => Math.min(24, s + 2))}
            disabled={fontSize >= 24}
          >
            A+
          </Button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <article className="max-w-[var(--content-max-width)] mx-auto px-6 py-8">
          <header className="mb-8">
            <h1
              className="text-2xl md:text-3xl font-bold text-text-primary leading-tight mb-4"
              style={{ fontSize: `${fontSize + 8}px` }}
            >
              {item.title}
            </h1>

            <div className="flex items-center gap-4 text-sm text-text-secondary">
              {feed && (
                <div className="flex items-center gap-2">
                  {feed.favicon_url ? (
                    <img
                      src={feed.favicon_url}
                      alt=""
                      className="h-4 w-4 rounded-sm"
                    />
                  ) : (
                    <Rss className="h-4 w-4" />
                  )}
                  <span>{feed.title}</span>
                </div>
              )}
              {item.author && (
                <div className="flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5" />
                  <span>{item.author}</span>
                </div>
              )}
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" />
                <span>{formatDate(item.published_at)}</span>
              </div>
            </div>
          </header>

          <div
            className="prose prose-neutral dark:prose-invert max-w-none"
            style={{ fontSize: `${fontSize}px`, lineHeight: 1.7 }}
          >
            {content ? (
              <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(content) }} />
            ) : (
              <p className="text-text-secondary italic">
                No content available.{" "}
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:underline"
                >
                  Read on the original site
                </a>
              </p>
            )}
          </div>

          <div className="mt-12 pt-6 border-t border-border">
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                {prevItem && (
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => {
                      if (prevItem) markAsRead(prevItem.id);
                    }}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                {nextItem && (
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => {
                      if (nextItem) markAsRead(nextItem.id);
                    }}
                  >
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        </article>
      </div>
    </div>
  );
}

function sanitizeHtml(html: string): string {
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "")
    .replace(/on\w+="[^"]*"/gi, "")
    .replace(/on\w+='[^']*'/gi, "");
}
