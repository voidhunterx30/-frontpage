"use client";

import { useState, useRef } from "react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui";
import {
  Upload,
  Download,
  FileText,
  CheckCircle2,
  AlertCircle,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { parseOpml, generateOpml, downloadOpml } from "@/lib/opml";

export function OpmlImportExport() {
  const { feeds, categories, setFeeds } = useAppStore();
  const [showImport, setShowImport] = useState(false);
  const [importResult, setImportResult] = useState<{
    success: boolean;
    added: number;
    skipped: number;
    errors: number;
    message: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const feedData = feeds.map((f) => ({
      title: f.custom_title || f.title,
      feed_url: f.feed_url,
      site_url: f.site_url,
      category:
        categories.find((c) => c.id === f.category_id)?.name || "Uncategorized",
    }));

    const opml = generateOpml(feedData);
    downloadOpml(opml);
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const text = await file.text();
    const parsed = parseOpml(text);

    if (parsed.length === 0) {
      setImportResult({
        success: false,
        added: 0,
        skipped: 0,
        errors: 1,
        message: "No valid feeds found in the OPML file",
      });
      return;
    }

    const existingUrls = new Set(feeds.map((f) => f.feed_url));
    let added = 0;
    let skipped = 0;

    const newFeeds = parsed.filter((feed) => {
      if (existingUrls.has(feed.feedUrl)) {
        skipped++;
        return false;
      }
      existingUrls.add(feed.feedUrl);
      added++;
      return true;
    });

    if (newFeeds.length > 0) {
      // Create categories for new feeds
      const existingCatNames = new Set(categories.map((c) => c.name.toLowerCase()));
      const newCategories = [...new Set(newFeeds.map((f) => f.category))]
        .filter((name) => !existingCatNames.has(name.toLowerCase()))
        .map((name, index) => ({
          id: `import-cat-${Date.now()}-${index}`,
          user_id: "local",
          name,
          order_index: categories.length + index,
          created_at: new Date().toISOString(),
        }));

      if (newCategories.length > 0) {
        const updatedCategories = [...categories, ...newCategories];
        useAppStore.getState().setCategories(updatedCategories);

        const catMap = new Map(updatedCategories.map((c) => [c.name.toLowerCase(), c.id]));

        const feedItems = newFeeds.map((f) => ({
          id: `import-feed-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          user_id: "local",
          title: f.title,
          feed_url: f.feedUrl,
          site_url: f.siteUrl,
          description: "",
          favicon_url: "",
          category_id: catMap.get(f.category.toLowerCase()) || null,
          last_fetched_at: null,
          last_error: null,
          health: "active" as const,
          created_at: new Date().toISOString(),
        }));

        setFeeds([...feeds, ...feedItems]);
      } else {
        const catMap = new Map(categories.map((c) => [c.name.toLowerCase(), c.id]));
        const feedItems = newFeeds.map((f) => ({
          id: `import-feed-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          user_id: "local",
          title: f.title,
          feed_url: f.feedUrl,
          site_url: f.siteUrl,
          description: "",
          favicon_url: "",
          category_id: catMap.get(f.category.toLowerCase()) || null,
          last_fetched_at: null,
          last_error: null,
          health: "active" as const,
          created_at: new Date().toISOString(),
        }));
        setFeeds([...feeds, ...feedItems]);
      }
    }

    setImportResult({
      success: true,
      added,
      skipped,
      errors: 0,
      message: `Import complete: ${added} feeds added, ${skipped} duplicates skipped`,
    });

    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-text-primary">OPML Import/Export</h3>
        <div className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept=".opml,.xml"
            onChange={handleImport}
            className="hidden"
          />
          <Button
            variant="secondary"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="h-3.5 w-3.5" />
            Import
          </Button>
          <Button variant="secondary" size="sm" onClick={handleExport}>
            <Download className="h-3.5 w-3.5" />
            Export
          </Button>
        </div>
      </div>

      {importResult && (
        <div
          className={cn(
            "flex items-start gap-3 p-3 rounded-lg animate-fade-in",
            importResult.success ? "bg-success/10" : "bg-error/10"
          )}
        >
          {importResult.success ? (
            <CheckCircle2 className="h-4 w-4 text-success mt-0.5 shrink-0" />
          ) : (
            <AlertCircle className="h-4 w-4 text-error mt-0.5 shrink-0" />
          )}
          <div className="flex-1">
            <p
              className={cn(
                "text-sm",
                importResult.success ? "text-success" : "text-error"
              )}
            >
              {importResult.message}
            </p>
          </div>
          <button
            onClick={() => setImportResult(null)}
            className="text-text-tertiary hover:text-text-primary"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      <p className="text-xs text-text-tertiary">
        Import feeds from an OPML file exported from another reader, or export your current subscriptions.
      </p>
    </div>
  );
}
