"use client";

import { useAppStore } from "@/lib/store";
import { ReaderView } from "@/components/reader-view";

export default function ReaderPage({ params }: { params: { id: string } }) {
  return <ReaderView itemId={params.id} />;
}
