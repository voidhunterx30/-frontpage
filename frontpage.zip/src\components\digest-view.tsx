"use client";

import { useAppStore } from "@/lib/store";
import { FeedItemCard } from "@/components/feed-item";
import { Inbox, Clock, TrendingUp, Sparkles } from "lucide-react";
import { cn, timeAgo, stripHtml, truncate } from "@/lib/utils";

export function DigestView() {
  const { items, feeds, categories, preferences } = useAppStore();

  const now = new Date();
  const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const recentItems = items
    .filter((i) => new Date(i.published_at) >= oneDayAgo)
    .sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());

  const unreadItems = items
    .filter((i) => !i.is_read)
    .sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());

  const weeklyItems = items
    .filter((i) => new Date(i.published_at) >= oneWeekAgo && !i.is_read)
    .sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());

  const topByCategory = categories.map((cat) => {
    const catFeeds = feeds.filter((f) => f.category_id === cat.id);
    const catItems = unreadItems.filter((i) =>
      catFeeds.some((f) => f.id === i.feed_id)
    );
    return {
      category: cat.name,
      items: catItems.slice(0, 3),
      total: catItems.length,
    };
  }).filter((c) => c.items.length > 0);

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="h-5 w-5 text-accent" />
          <h1 className="text-xl font-semibold text-text-primary">Daily Digest</h1>
        </div>
        <p className="text-sm text-text-secondary">
          What you missed since your last visit
        </p>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="p-4 rounded-xl border border-border bg-bg-surface text-center">
          <div className="text-2xl font-bold text-accent">{recentItems.length}</div>
          <div className="text-xs text-text-tertiary mt-0.5">New today</div>
        </div>
        <div className="p-4 rounded-xl border border-border bg-bg-surface text-center">
          <div className="text-2xl font-bold text-warning">{unreadItems.length}</div>
          <div className="text-xs text-text-tertiary mt-0.5">Unread total</div>
        </div>
        <div className="p-4 rounded-xl border border-border bg-bg-surface text-center">
          <div className="text-2xl font-bold text-success">{weeklyItems.length}</div>
          <div className="text-xs text-text-tertiary mt-0.5">This week</div>
        </div>
      </div>

      {recentItems.length > 0 && (
        <section className="mb-8">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="h-4 w-4 text-accent" />
            <h2 className="text-base font-semibold text-text-primary">
              Fresh Stories
            </h2>
            <span className="text-xs text-text-tertiary">
              Last 24 hours
            </span>
          </div>
          <div className="space-y-2">
            {recentItems.slice(0, 10).map((item) => (
              <FeedItemCard key={item.id} item={item} layout="magazine" />
            ))}
          </div>
        </section>
      )}

      {topByCategory.length > 0 && (
        <section className="mb-8">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="h-4 w-4 text-accent" />
            <h2 className="text-base font-semibold text-text-primary">
              By Category
            </h2>
          </div>
          <div className="space-y-6">
            {topByCategory.map((cat) => (
              <div key={cat.category}>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-text-primary">
                    {cat.category}
                  </h3>
                  <span className="text-xs text-text-tertiary">
                    {cat.total} unread
                  </span>
                </div>
                <div className="space-y-2">
                  {cat.items.map((item) => (
                    <FeedItemCard key={item.id} item={item} layout="list" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {unreadItems.length === 0 && (
        <div className="text-center py-16">
          <Inbox className="h-12 w-12 text-text-tertiary mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-text-primary mb-1">
            All caught up!
          </h2>
          <p className="text-sm text-text-secondary">
            No unread articles. Check back later for new content.
          </p>
        </div>
      )}
    </div>
  );
}
