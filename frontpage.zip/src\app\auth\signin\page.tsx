"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button, Input } from "@/components/ui";
import { Zap, Eye, EyeOff } from "lucide-react";

export default function SignInPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (res.ok) {
        localStorage.setItem("frontpage_user", JSON.stringify(data.user));
        router.push("/dashboard");
      } else {
        setError(data.error || "Failed to sign in");
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg-primary flex">
      <div className="hidden lg:flex lg:w-1/2 bg-bg-secondary items-center justify-center p-12">
        <div className="max-w-md">
          <div className="flex items-center gap-2 mb-8">
            <Zap className="h-8 w-8 text-accent" />
            <span className="text-2xl font-bold text-text-primary">Frontpage</span>
          </div>
          <h1 className="text-3xl font-bold text-text-primary mb-4">
            Welcome back
          </h1>
          <p className="text-text-secondary text-lg leading-relaxed">
            Sign in to access your personalized feed dashboard. Your reading
            list, bookmarks, and preferences are waiting for you.
          </p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <Zap className="h-6 w-6 text-accent" />
            <span className="text-xl font-bold text-text-primary">Frontpage</span>
          </div>

          <h2 className="text-xl font-semibold text-text-primary mb-1">
            Sign in to your account
          </h2>
          <p className="text-sm text-text-secondary mb-6">
            Or{" "}
            <Link href="/auth/signup" className="text-accent hover:underline">
              create a new account
            </Link>
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <div className="relative">
              <Input
                label="Password"
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-[38px] text-text-tertiary hover:text-text-secondary"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            </div>

            {error && (
              <p className="text-sm text-error bg-error/10 p-2 rounded-lg">
                {error}
              </p>
            )}

            <Button
              type="submit"
              variant="primary"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? "Signing in..." : "Sign In"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <Link
              href="/auth/reset"
              className="text-sm text-accent hover:underline"
            >
              Forgot your password?
            </Link>
          </div>

          <div className="mt-8 pt-6 border-t border-border text-center">
            <Link href="/guest">
              <Button variant="secondary" className="w-full">
                Try as Guest
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
