import { XMLParser, XMLBuilder } from "fast-xml-parser";

export interface ParsedFeed {
  title: string;
  description: string;
  siteUrl: string;
  feedUrl: string;
  items: ParsedFeedItem[];
  format: "rss2" | "atom" | "rss1";
}

export interface ParsedFeedItem {
  title: string;
  url: string;
  author: string | null;
  description: string | null;
  content: string | null;
  publishedAt: Date;
  imageUrl: string | null;
}

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  allowBooleanAttributes: true,
  parseTagValue: true,
  parseAttributeValue: true,
  trimValues: true,
  isArray: (name) => {
    return name === "item" || name === "entry" || name === "category";
  },
});

function decodeHtmlEntities(text: string): string {
  if (!text) return "";
  return text
    .replace(/&#x27;/g, "'")
    .replace(/&#x2F;/g, "/")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(parseInt(code)))
    .replace(/&nbsp;/g, " ");
}

function extractImageUrl(content: string | null, description: string | null): string | null {
  const html = content || description || "";
  const match = html.match(/<img[^>]+src=["']([^"']+)["']/i);
  return match ? match[1] : null;
}

function parseDate(dateStr: string | null | undefined): Date {
  if (!dateStr) return new Date();

  const cleaned = dateStr.trim();
  const date = new Date(cleaned);
  if (!isNaN(date.getTime())) return date;

  const rfc822Match = cleaned.match(
    /(\d{1,2})\s+(\w{3})\s+(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?\s+(\w+)/
  );
  if (rfc822Match) {
    const months: Record<string, number> = {
      Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
      Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11,
    };
    const month = months[rfc822Match[2].toLowerCase()];
    if (month !== undefined) {
      return new Date(
        parseInt(rfc822Match[3]),
        month,
        parseInt(rfc822Match[1]),
        parseInt(rfc822Match[4]),
        parseInt(rfc822Match[5]),
        rfc822Match[6] ? parseInt(rfc822Match[6]) : 0
      );
    }
  }

  return new Date();
}

function parseRss2(root: Record<string, Record<string, Record<string, unknown>>>): ParsedFeed {
  const channel = root?.rss?.channel || {};
  const items = Array.isArray(channel.item) ? channel.item : channel.item ? [channel.item] : [];

  return {
    title: decodeHtmlEntities(String(channel.title || "")),
    description: decodeHtmlEntities(String(channel.description || "")),
    siteUrl: String(channel.link || ""),
    feedUrl: "",
    format: "rss2",
    items: items.map((item: Record<string, unknown>) => ({
      title: decodeHtmlEntities(String(item.title || "Untitled")),
      url: String(item.link || item.guid || ""),
      author: item.author ? String(item.author) : item["dc:creator"] ? String(item["dc:creator"]) : null,
      description: item.description ? decodeHtmlEntities(String(item.description)) : null,
      content: item["content:encoded"] ? decodeHtmlEntities(String(item["content:encoded"])) : item.description ? decodeHtmlEntities(String(item.description)) : null,
      publishedAt: parseDate(String(item.pubDate || item["dc:date"] || "")),
      imageUrl: extractImageUrl(
        item["content:encoded"] ? String(item["content:encoded"]) : null,
        item.description ? String(item.description) : null
      ),
    })),
  };
}

function parseAtom(root: Record<string, Record<string, unknown>>): ParsedFeed {
  const feed = root?.feed || {};
  const entries = Array.isArray(feed.entry) ? feed.entry : feed.entry ? [feed.entry] : [];

  return {
    title: decodeHtmlEntities(String(feed.title || "")),
    description: decodeHtmlEntities(String(feed.subtitle || "")),
    siteUrl: feed.link ? String(feed.link) : "",
    feedUrl: "",
    format: "atom",
    items: entries.map((entry: Record<string, any>) => {
      const link = entry.link;
      const href = typeof link === "object" && link?.["@_href"] ? String(link["@_href"]) : typeof link === "string" ? link : "";
      const content = entry.content;
      const contentValue = typeof content === "object" && content?.["#text"] ? String(content["#text"]) : typeof content === "string" ? content : null;
      const summary = entry.summary;
      const summaryValue = typeof summary === "object" && summary?.["#text"] ? String(summary["#text"]) : typeof summary === "string" ? summary : null;

      return {
        title: decodeHtmlEntities(String(entry.title || "Untitled")),
        url: String(href),
        author: entry.author?.name ? String(entry.author.name) : null,
        description: summaryValue ? decodeHtmlEntities(summaryValue) : null,
        content: contentValue ? decodeHtmlEntities(contentValue) : summaryValue ? decodeHtmlEntities(summaryValue) : null,
        publishedAt: parseDate(String(entry.updated || entry.published || "")),
        imageUrl: extractImageUrl(contentValue, summaryValue),
      };
    }),
  };
}

function parseRss1(root: Record<string, Record<string, Record<string, unknown>>>): ParsedFeed {
  const rdf = root?.["rdf:RDF"] || {};
  const items = Array.isArray(rdf.item) ? rdf.item : rdf.item ? [rdf.item] : [];

  return {
    title: decodeHtmlEntities(String(rdf.channel?.title || "")),
    description: decodeHtmlEntities(String(rdf.channel?.description || "")),
    siteUrl: String(rdf.channel?.link || ""),
    feedUrl: "",
    format: "rss1",
    items: items.map((item: Record<string, unknown>) => ({
      title: decodeHtmlEntities(String(item.title || "Untitled")),
      url: String(item.link || item["dc:identifier"] || ""),
      author: item["dc:creator"] ? String(item["dc:creator"]) : null,
      description: item.description ? decodeHtmlEntities(String(item.description)) : null,
      content: item["content:encoded"] ? decodeHtmlEntities(String(item["content:encoded"])) : item.description ? decodeHtmlEntities(String(item.description)) : null,
      publishedAt: parseDate(String(item["dc:date"] || "")),
      imageUrl: extractImageUrl(
        item["content:encoded"] ? String(item["content:encoded"]) : null,
        item.description ? String(item.description) : null
      ),
    })),
  };
}

export function parseFeed(xml: string, feedUrl?: string): ParsedFeed {
  const root = parser.parse(xml);

  let feed: ParsedFeed;
  if (root.rss) {
    feed = parseRss2(root);
  } else if (root.feed) {
    feed = parseAtom(root);
  } else if (root["rdf:RDF"] || root.RDF) {
    feed = parseRss1(root["rdf:RDF"] ? root : { "rdf:RDF": root });
  } else {
    throw new Error("Unrecognized feed format");
  }

  if (feedUrl) feed.feedUrl = feedUrl;
  return feed;
}

export async function fetchAndParseFeed(feedUrl: string): Promise<ParsedFeed> {
  const response = await fetch(feedUrl, {
    headers: {
      "User-Agent": "Frontpage/1.0 RSS Reader",
      Accept: "application/rss+xml, application/atom+xml, application/xml, text/xml",
    },
    signal: AbortSignal.timeout(10000),
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch feed: ${response.status} ${response.statusText}`);
  }

  const xml = await response.text();
  return parseFeed(xml, feedUrl);
}
