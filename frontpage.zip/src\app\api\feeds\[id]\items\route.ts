import { NextResponse } from "next/server";
import { fetchAndParseFeed } from "@/lib/feed-parser";
import type { ParsedFeedItem } from "@/lib/feed-parser";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { url } = body;

    if (!url) {
      return NextResponse.json({ error: "Feed URL is required" }, { status: 400 });
    }

    const parsed = await fetchAndParseFeed(url);

    const items = parsed.items.map((item: ParsedFeedItem, index: number) => ({
      id: crypto.randomUUID(),
      feed_id: "guest",
      title: item.title,
      url: item.url,
      author: item.author,
      description: item.description,
      content: item.content,
      published_at: item.publishedAt.toISOString(),
      image_url: item.imageUrl,
      is_read: false,
      is_bookmarked: false,
      created_at: new Date().toISOString(),
    }));

    return NextResponse.json({
      title: parsed.title,
      description: parsed.description,
      siteUrl: parsed.siteUrl,
      items,
    });
  } catch (error) {
    console.error("Fetch feed error:", error);
    return NextResponse.json(
      { error: `Failed to fetch feed: ${error instanceof Error ? error.message : "Unknown error"}` },
      { status: 500 }
    );
  }
}
