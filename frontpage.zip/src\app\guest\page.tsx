"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import { Sidebar } from "@/components/sidebar";
import { FeedListView } from "@/components/feed-list-view";
import { SearchView } from "@/components/search-view";
import { BookmarksView } from "@/components/bookmarks-view";
import { AnalyticsView } from "@/components/analytics-view";
import { DigestView } from "@/components/digest-view";
import { CommandPalette } from "@/components/command-palette";
import { GUEST_FEEDS } from "@/lib/guest-feeds";
import { getFaviconUrl } from "@/lib/utils";
import type { Feed, FeedItem, Category } from "@/lib/types";

export default function GuestPage() {
  const router = useRouter();
  const {
    setFeeds,
    setItems,
    setCategories,
    setIsGuest,
    setLoading,
    currentView,
    setSelectedFeed,
    setSelectedCategory,
  } = useAppStore();
  const [isLoaded, setIsLoaded] = useState(false);

  const loadGuestData = useCallback(async () => {
    setIsGuest(true);

    const categories: Category[] = GUEST_FEEDS.map((cat, index) => ({
      id: `cat-${index}`,
      user_id: "guest",
      name: cat.name,
      order_index: index,
      created_at: new Date().toISOString(),
    }));
    setCategories(categories);

    const allFeeds: Feed[] = [];
    const allItems: FeedItem[] = [];

    setLoading(true);

    const feedPromises = GUEST_FEEDS.flatMap((cat, catIndex) =>
      cat.feeds.map(async (feedData) => {
        try {
          const res = await fetch("/api/feeds/[id]/items", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: feedData.feedUrl }),
          });

          if (!res.ok) return;

          const data = await res.json();

          const feed: Feed = {
            id: `feed-${Date.now()}-${Math.random().toString(36).slice(2)}`,
            user_id: "guest",
            title: data.title || feedData.title,
            feed_url: feedData.feedUrl,
            site_url: feedData.siteUrl,
            description: data.description || feedData.description,
            favicon_url: getFaviconUrl(feedData.siteUrl),
            category_id: `cat-${catIndex}`,
            last_fetched_at: new Date().toISOString(),
            last_error: null,
            health: "active",
            created_at: new Date().toISOString(),
          };

          const items: FeedItem[] = (data.items || []).map(
            (item: any, index: number) => ({
              id: `item-${Date.now()}-${Math.random().toString(36).slice(2)}-${index}`,
              feed_id: feed.id,
              title: item.title,
              url: item.url,
              author: item.author,
              description: item.description,
              content: item.content,
              published_at: item.published_at,
              image_url: item.image_url,
              is_read: false,
              is_bookmarked: false,
              created_at: new Date().toISOString(),
            })
          );

          allFeeds.push(feed);
          allItems.push(...items);
        } catch (err) {
          console.warn(`Failed to load feed: ${feedData.title}`, err);
        }
      })
    );

    await Promise.allSettled(feedPromises);

    setFeeds(allFeeds);
    setItems(
      allItems.sort(
        (a, b) =>
          new Date(b.published_at).getTime() -
          new Date(a.published_at).getTime()
      )
    );
    setLoading(false);
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    loadGuestData();
  }, [loadGuestData]);

  useEffect(() => {
    setSelectedFeed(null);
    setSelectedCategory(null);
  }, []);

  const renderView = () => {
    switch (currentView) {
      case "search":
        return <SearchView />;
      case "bookmarks":
        return <BookmarksView />;
      case "analytics":
        return <AnalyticsView />;
      case "digest":
        return <DigestView />;
      default:
        return <FeedListView />;
    }
  };

  return (
    <div className="h-screen flex bg-bg-primary">
      <CommandPalette />
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        {!isLoaded ? (
          <div className="flex flex-col items-center justify-center h-full">
            <div className="h-10 w-10 border-2 border-accent border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-sm text-text-secondary">
              Loading your guest dashboard...
            </p>
            <p className="text-xs text-text-tertiary mt-1">
              Fetching real content from 19 curated feeds
            </p>
          </div>
        ) : (
          renderView()
        )}
      </main>
    </div>
  );
}
