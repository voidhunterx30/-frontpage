export interface GuestFeedData {
  title: string;
  feedUrl: string;
  siteUrl: string;
  description: string;
  format: string;
  category: string;
}

export interface GuestCategory {
  name: string;
  feeds: GuestFeedData[];
}

export const GUEST_FEEDS: GuestCategory[] = [
  {
    name: "Frontend",
    feeds: [
      { title: "CSS-Tricks", feedUrl: "https://css-tricks.com/feed/", siteUrl: "https://css-tricks.com/", description: "Tips, Tricks, and Techniques on using Cascading Style Sheets.", format: "rss2", category: "Frontend" },
      { title: "Smashing Magazine", feedUrl: "https://www.smashingmagazine.com/feed/", siteUrl: "https://www.smashingmagazine.com/", description: "For web designers and developers.", format: "rss2", category: "Frontend" },
      { title: "Josh W. Comeau", feedUrl: "https://www.joshwcomeau.com/rss.xml", siteUrl: "https://www.joshwcomeau.com/", description: "Friendly tutorials for developers.", format: "rss2", category: "Frontend" },
      { title: "Kent C. Dodds", feedUrl: "https://kentcdodds.com/blog/rss.xml", siteUrl: "https://kentcdodds.com/", description: "Helping people make the world a better place through quality software.", format: "rss2", category: "Frontend" },
      { title: "web.dev", feedUrl: "https://web.dev/feed.xml", siteUrl: "https://web.dev/", description: "Building a better web, together.", format: "atom", category: "Frontend" },
      { title: "MDN Blog", feedUrl: "https://developer.mozilla.org/en-US/blog/rss.xml", siteUrl: "https://developer.mozilla.org/en-US/blog/", description: "The MDN Web Docs blog.", format: "rss2", category: "Frontend" },
    ],
  },
  {
    name: "Design",
    feeds: [
      { title: "Sidebar.io", feedUrl: "https://sidebar.io/feed.xml", siteUrl: "https://sidebar.io/", description: "The five best design links, every day.", format: "atom", category: "Design" },
      { title: "Nielsen Norman Group", feedUrl: "https://www.nngroup.com/feed/rss/", siteUrl: "https://www.nngroup.com/", description: "Evidence-based user experience research, training, and consulting.", format: "rss2", category: "Design" },
      { title: "Figma Blog", feedUrl: "https://www.figma.com/blog/feed/", siteUrl: "https://www.figma.com/blog/", description: "Stories about how products are designed at Figma and beyond.", format: "rss2", category: "Design" },
      { title: "A List Apart", feedUrl: "https://alistapart.com/main/feed/", siteUrl: "https://alistapart.com/", description: "For people who make websites.", format: "rss2", category: "Design" },
      { title: "UX Collective", feedUrl: "https://uxdesign.cc/feed", siteUrl: "https://uxdesign.cc/", description: "Curated stories on user experience, usability, and product design.", format: "rss2", category: "Design" },
    ],
  },
  {
    name: "Backend & DevOps",
    feeds: [
      { title: "Cloudflare Blog", feedUrl: "https://blog.cloudflare.com/rss/", siteUrl: "https://blog.cloudflare.com/", description: "The Cloudflare Blog.", format: "rss2", category: "Backend & DevOps" },
      { title: "Vercel Blog", feedUrl: "https://vercel.com/atom", siteUrl: "https://vercel.com/blog", description: "Updates from Vercel.", format: "atom", category: "Backend & DevOps" },
      { title: "The GitHub Blog", feedUrl: "https://github.blog/feed/", siteUrl: "https://github.blog/", description: "Updates, ideas, and inspiration from GitHub.", format: "rss2", category: "Backend & DevOps" },
      { title: "Netlify Blog", feedUrl: "https://www.netlify.com/blog/index.xml", siteUrl: "https://www.netlify.com/blog/", description: "News and posts from Netlify.", format: "rss2", category: "Backend & DevOps" },
    ],
  },
  {
    name: "General Tech",
    feeds: [
      { title: "The Pragmatic Engineer", feedUrl: "https://blog.pragmaticengineer.com/rss/", siteUrl: "https://blog.pragmaticengineer.com/", description: "Observations across the software engineering industry.", format: "rss2", category: "General Tech" },
      { title: "Hacker News Best", feedUrl: "https://hnrss.org/best", siteUrl: "https://news.ycombinator.com/", description: "Best stories on Hacker News.", format: "rss2", category: "General Tech" },
    ],
  },
  {
    name: "AI & ML",
    feeds: [
      { title: "Simon Willison's Weblog", feedUrl: "https://simonwillison.net/atom/everything/", siteUrl: "https://simonwillison.net/", description: "Simon Willison's weblog, covering AI, Python, and web development.", format: "atom", category: "AI & ML" },
      { title: "Hugging Face Blog", feedUrl: "https://huggingface.co/blog/feed.xml", siteUrl: "https://huggingface.co/blog", description: "The latest news from Hugging Face.", format: "atom", category: "AI & ML" },
    ],
  },
];
