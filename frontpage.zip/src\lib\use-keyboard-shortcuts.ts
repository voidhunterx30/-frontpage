"use client";

import { useEffect } from "react";
import { useAppStore } from "@/lib/store";

export function useKeyboardShortcuts() {
  const {
    setCurrentView,
    setSelectedFeed,
    setSelectedCategory,
    setPreferences,
    preferences,
    markAllAsRead,
  } = useAppStore();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.isContentEditable
      ) {
        return;
      }

      if (e.key === "/" && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        setCurrentView("search");
      }

      if (e.key === "l" && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        const layouts = ["list", "cards", "magazine"] as const;
        const currentIndex = layouts.indexOf(preferences.layout);
        const nextIndex = (currentIndex + 1) % layouts.length;
        setPreferences({ layout: layouts[nextIndex] });
      }

      if (e.key === "a" && e.shiftKey && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        markAllAsRead();
      }

      if (e.key === "g" && !e.metaKey && !e.ctrlKey) {
        const handler2 = (e2: KeyboardEvent) => {
          if (e2.key === "h") {
            setCurrentView("feed");
            setSelectedFeed(null);
            setSelectedCategory(null);
          }
          if (e2.key === "s") {
            setCurrentView("bookmarks");
          }
          if (e2.key === "f") {
            setCurrentView("feed");
          }
          window.removeEventListener("keydown", handler2);
        };
        window.addEventListener("keydown", handler2, { once: true });
        setTimeout(() => window.removeEventListener("keydown", handler2), 1000);
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [preferences.layout]);
}
