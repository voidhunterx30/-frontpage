import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const { email, password } = await request.json();

  if (!email || !password) {
    return NextResponse.json(
      { error: "Email and password are required" },
      { status: 400 }
    );
  }

  if (password.length < 8) {
    return NextResponse.json(
      { error: "Password must be at least 8 characters" },
      { status: 400 }
    );
  }

  return NextResponse.json({
    user: {
      id: "new-user",
      email,
      created_at: new Date().toISOString(),
    },
    session: { access_token: "demo-token" },
  });
}
