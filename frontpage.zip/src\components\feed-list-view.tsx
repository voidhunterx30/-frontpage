"use client";

import { useEffect, useCallback } from "react";
import { useAppStore } from "@/lib/store";
import { FeedItemCard, FeedItemSkeleton } from "@/components/feed-item";
import { Button } from "@/components/ui";
import { RefreshCw, CheckCheck, LayoutGrid, List, LayoutTemplate } from "lucide-react";
import { cn } from "@/lib/utils";

export function FeedListView() {
  const {
    items,
    feeds,
    categories,
    selectedFeedId,
    selectedCategoryId,
    preferences,
    isLoading,
    setPreferences,
    markAllAsRead,
    getFilteredItems,
    getUnreadCount,
    setCurrentView,
  } = useAppStore();

  const filteredItems = getFilteredItems();
  const selectedFeed = selectedFeedId
    ? feeds.find((f) => f.id === selectedFeedId)
    : null;
  const selectedCategory = selectedCategoryId
    ? categories.find((c) => c.id === selectedCategoryId)
    : null;

  const title = selectedFeed
    ? selectedFeed.custom_title || selectedFeed.title
    : selectedCategory
    ? selectedCategory.name
    : "All Items";

  const unreadCount = selectedFeedId
    ? getUnreadCount(selectedFeedId)
    : selectedCategoryId
    ? getUnreadCount(undefined, selectedCategoryId)
    : getUnreadCount();

  return (
    <div className="flex flex-col h-full">
      <header className="h-14 border-b border-border flex items-center gap-3 px-4 shrink-0 bg-bg-primary">
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-semibold text-text-primary truncate">
            {title}
          </h1>
          {unreadCount > 0 && (
            <p className="text-xs text-text-tertiary">
              {unreadCount} unread
            </p>
          )}
        </div>

        <div className="flex items-center gap-1">
          <div className="hidden md:flex items-center bg-bg-tertiary rounded-lg p-0.5">
            {(["list", "cards", "magazine"] as const).map((layout) => (
              <button
                key={layout}
                onClick={() => setPreferences({ layout })}
                className={cn(
                  "h-7 px-2.5 rounded-md text-xs font-medium transition-colors",
                  preferences.layout === layout
                    ? "bg-bg-surface text-text-primary shadow-sm"
                    : "text-text-tertiary hover:text-text-secondary"
                )}
                title={`${layout} view`}
              >
                {layout === "list" && <List className="h-3.5 w-3.5" />}
                {layout === "cards" && <LayoutGrid className="h-3.5 w-3.5" />}
                {layout === "magazine" && (
                  <LayoutTemplate className="h-3.5 w-3.5" />
                )}
              </button>
            ))}
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => markAllAsRead(selectedFeedId || undefined, selectedCategoryId || undefined)}
            disabled={unreadCount === 0}
            title="Mark all as read"
          >
            <CheckCheck className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {isLoading && filteredItems.length === 0 ? (
          <div>
            {Array.from({ length: 8 }).map((_, i) => (
              <FeedItemSkeleton key={i} layout={preferences.layout} />
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="h-16 w-16 rounded-2xl bg-bg-tertiary flex items-center justify-center mb-4">
              <RefreshCw className="h-8 w-8 text-text-tertiary" />
            </div>
            <h2 className="text-lg font-semibold text-text-primary mb-1">
              No articles yet
            </h2>
            <p className="text-sm text-text-secondary max-w-sm">
              Add some feeds to get started, or check back later for new content.
            </p>
          </div>
        ) : preferences.layout === "cards" ? (
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredItems.map((item) => (
              <FeedItemCard key={item.id} item={item} layout="cards" />
            ))}
          </div>
        ) : preferences.layout === "magazine" ? (
          <div className="p-4 space-y-3">
            {filteredItems.map((item) => (
              <FeedItemCard key={item.id} item={item} layout="magazine" />
            ))}
          </div>
        ) : (
          <div>
            {filteredItems.map((item) => (
              <FeedItemCard key={item.id} item={item} layout="list" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
