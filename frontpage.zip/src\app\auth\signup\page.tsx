"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button, Input } from "@/components/ui";
import { Zap, Eye, EyeOff } from "lucide-react";

export default function SignUpPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords don't match");
      return;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (res.ok) {
        localStorage.setItem("frontpage_user", JSON.stringify(data.user));
        router.push("/dashboard");
      } else {
        setError(data.error || "Failed to create account");
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg-primary flex">
      <div className="hidden lg:flex lg:w-1/2 bg-bg-secondary items-center justify-center p-12">
        <div className="max-w-md">
          <div className="flex items-center gap-2 mb-8">
            <Zap className="h-8 w-8 text-accent" />
            <span className="text-2xl font-bold text-text-primary">Frontpage</span>
          </div>
          <h1 className="text-3xl font-bold text-text-primary mb-4">
            Your personalized front page
          </h1>
          <p className="text-text-secondary text-lg leading-relaxed">
            Create an account to sync your feeds, bookmarks, and preferences
            across devices. Start building your perfect reading experience.
          </p>
          <ul className="mt-8 space-y-3">
            {[
              "Sync across all your devices",
              "Save unlimited bookmarks",
              "Custom categories and layouts",
              "Reading analytics and digest",
            ].map((feature) => (
              <li
                key={feature}
                className="flex items-center gap-2 text-text-secondary"
              >
                <div className="h-5 w-5 rounded-full bg-success/10 flex items-center justify-center">
                  <svg className="h-3 w-3 text-success" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                    <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                {feature}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <Zap className="h-6 w-6 text-accent" />
            <span className="text-xl font-bold text-text-primary">Frontpage</span>
          </div>

          <h2 className="text-xl font-semibold text-text-primary mb-1">
            Create your account
          </h2>
          <p className="text-sm text-text-secondary mb-6">
            Or{" "}
            <Link href="/auth/signin" className="text-accent hover:underline">
              sign in to your existing account
            </Link>
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <div className="relative">
              <Input
                label="Password"
                type={showPassword ? "text" : "password"}
                placeholder="At least 8 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-[38px] text-text-tertiary hover:text-text-secondary"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            </div>

            <Input
              label="Confirm Password"
              type={showPassword ? "text" : "password"}
              placeholder="Repeat your password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />

            {error && (
              <p className="text-sm text-error bg-error/10 p-2 rounded-lg">
                {error}
              </p>
            )}

            <Button
              type="submit"
              variant="primary"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? "Creating account..." : "Create Account"}
            </Button>
          </form>

          <div className="mt-8 pt-6 border-t border-border text-center">
            <Link href="/guest">
              <Button variant="secondary" className="w-full">
                Try as Guest
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
