"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import { useKeyboardShortcuts } from "@/lib/use-keyboard-shortcuts";
import { Sidebar } from "@/components/sidebar";
import { FeedListView } from "@/components/feed-list-view";
import { SearchView } from "@/components/search-view";
import { BookmarksView } from "@/components/bookmarks-view";
import { AnalyticsView } from "@/components/analytics-view";
import { DigestView } from "@/components/digest-view";
import { SettingsView } from "@/components/settings-view";
import { CommandPalette } from "@/components/command-palette";
import { FeedManager } from "@/components/feed-manager";

export default function DashboardPage() {
  const router = useRouter();
  const { currentView, setSelectedFeed, setSelectedCategory } = useAppStore();

  useKeyboardShortcuts();

  useEffect(() => {
    setSelectedFeed(null);
    setSelectedCategory(null);
  }, []);

  const renderView = () => {
    switch (currentView) {
      case "search":
        return <SearchView />;
      case "bookmarks":
        return <BookmarksView />;
      case "analytics":
        return <AnalyticsView />;
      case "digest":
        return <DigestView />;
      case "settings":
        return <SettingsView />;
      default:
        return <FeedListView />;
    }
  };

  return (
    <div className="h-screen flex bg-bg-primary">
      <CommandPalette />
      <Sidebar />
      <main className="flex-1 overflow-hidden">{renderView()}</main>
    </div>
  );
}
