"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { Sun, Moon, Monitor } from "lucide-react";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  if (!mounted) {
    return (
      <button className="h-8 w-8 rounded-lg bg-bg-tertiary flex items-center justify-center">
        <Monitor className="h-4 w-4 text-text-tertiary" />
      </button>
    );
  }

  return (
    <button
      onClick={() => setTheme(theme === "dark" ? "light" : theme === "light" ? "system" : "dark")}
      className="h-8 w-8 rounded-lg bg-bg-tertiary hover:bg-border transition-colors flex items-center justify-center"
      title={`Current: ${theme}. Click to switch.`}
    >
      {theme === "dark" ? (
        <Moon className="h-4 w-4 text-text-secondary" />
      ) : theme === "light" ? (
        <Sun className="h-4 w-4 text-text-secondary" />
      ) : (
        <Monitor className="h-4 w-4 text-text-secondary" />
      )}
    </button>
  );
}
