"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui";
import { OpmlImportExport } from "@/components/opml-manager";
import { Settings, Save } from "lucide-react";

export function SettingsView() {
  const { preferences, setPreferences, feeds, categories } = useAppStore();
  const [localPrefs, setLocalPrefs] = useState({ ...preferences });

  const handleSave = () => {
    setPreferences(localPrefs);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="mb-8">
        <h1 className="text-xl font-semibold text-text-primary">Settings</h1>
        <p className="text-sm text-text-secondary mt-0.5">
          Customize your reading experience
        </p>
      </div>

      <div className="space-y-6">
        <section className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">Display</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-text-secondary mb-2 block">
                Default Layout
              </label>
              <div className="flex gap-2">
                {(["list", "cards", "magazine"] as const).map((layout) => (
                  <button
                    key={layout}
                    onClick={() => setLocalPrefs({ ...localPrefs, layout })}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      localPrefs.layout === layout
                        ? "bg-accent text-white"
                        : "bg-bg-tertiary text-text-secondary hover:bg-border"
                    }`}
                  >
                    {layout.charAt(0).toUpperCase() + layout.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm text-text-secondary mb-2 block">
                Show Read Items
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={localPrefs.show_read_items}
                  onChange={(e) =>
                    setLocalPrefs({
                      ...localPrefs,
                      show_read_items: e.target.checked,
                    })
                  }
                  className="h-4 w-4 rounded border-border text-accent focus:ring-accent/30"
                />
                <span className="text-sm text-text-primary">
                  Display read articles in the feed
                </span>
              </label>
            </div>
          </div>
        </section>

        <section className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">
            Auto-Refresh
          </h2>
          <div>
            <label className="text-sm text-text-secondary mb-2 block">
              Refresh Interval
            </label>
            <select
              value={localPrefs.refresh_interval}
              onChange={(e) =>
                setLocalPrefs({
                  ...localPrefs,
                  refresh_interval: parseInt(e.target.value),
                })
              }
              className="h-9 rounded-lg border bg-bg-primary px-3 text-sm text-text-primary border-border focus:border-accent focus:outline-none"
            >
              <option value={15}>Every 15 minutes</option>
              <option value={30}>Every 30 minutes</option>
              <option value={60}>Every hour</option>
              <option value={0}>Manual only</option>
            </select>
          </div>
        </section>

        <section className="p-5 rounded-xl border border-border bg-bg-surface">
          <OpmlImportExport />
        </section>

        <section className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">Keyboard Shortcuts</h2>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex justify-between"><span className="text-text-secondary">Command Palette</span><kbd className="px-1.5 py-0.5 rounded bg-bg-tertiary text-text-tertiary text-xs">Ctrl+K</kbd></div>
            <div className="flex justify-between"><span className="text-text-secondary">Search</span><kbd className="px-1.5 py-0.5 rounded bg-bg-tertiary text-text-tertiary text-xs">/</kbd></div>
            <div className="flex justify-between"><span className="text-text-secondary">Mark all read</span><kbd className="px-1.5 py-0.5 rounded bg-bg-tertiary text-text-tertiary text-xs">Shift+A</kbd></div>
            <div className="flex justify-between"><span className="text-text-secondary">Toggle layout</span><kbd className="px-1.5 py-0.5 rounded bg-bg-tertiary text-text-tertiary text-xs">L</kbd></div>
          </div>
        </section>

        <section className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">Data</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-text-primary">Total Feeds</p>
                <p className="text-xs text-text-tertiary">{feeds.length} feeds</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-text-primary">Categories</p>
                <p className="text-xs text-text-tertiary">
                  {categories.length} categories
                </p>
              </div>
            </div>
          </div>
        </section>

        <div className="flex justify-end">
          <Button variant="primary" onClick={handleSave}>
            <Save className="h-4 w-4" />
            Save Settings
          </Button>
        </div>
      </div>
    </div>
  );
}
