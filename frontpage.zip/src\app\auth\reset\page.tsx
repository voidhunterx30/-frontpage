"use client";

import { useState } from "react";
import Link from "next/link";
import { Button, Input } from "@/components/ui";
import { Zap, ArrowLeft, CheckCircle2 } from "lucide-react";

export default function ResetPasswordPage() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    setIsSubmitted(true);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-bg-primary flex items-center justify-center p-8">
      <div className="w-full max-w-sm">
        <Link
          href="/auth/signin"
          className="inline-flex items-center gap-1.5 text-sm text-text-secondary hover:text-text-primary mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to sign in
        </Link>

        <div className="flex items-center gap-2 mb-8">
          <Zap className="h-6 w-6 text-accent" />
          <span className="text-xl font-bold text-text-primary">Frontpage</span>
        </div>

        {isSubmitted ? (
          <div className="text-center">
            <CheckCircle2 className="h-12 w-12 text-success mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-text-primary mb-2">
              Check your email
            </h2>
            <p className="text-sm text-text-secondary mb-6">
              We sent a password reset link to <strong>{email}</strong>
            </p>
            <Link href="/auth/signin">
              <Button variant="primary" className="w-full">
                Return to Sign In
              </Button>
            </Link>
          </div>
        ) : (
          <>
            <h2 className="text-xl font-semibold text-text-primary mb-1">
              Reset your password
            </h2>
            <p className="text-sm text-text-secondary mb-6">
              Enter your email and we&apos;ll send you a reset link.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                label="Email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />

              <Button
                type="submit"
                variant="primary"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? "Sending..." : "Send Reset Link"}
              </Button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
