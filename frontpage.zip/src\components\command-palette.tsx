"use client";

import { useState, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/store";
import {
  Search,
  Home,
  Bookmark,
  Settings,
  BarChart3,
  Inbox,
  Rss,
  Layout,
  CheckCircle2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function CommandPalette() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const {
    feeds,
    categories,
    setCurrentView,
    setSelectedFeed,
    setSelectedCategory,
    markAllAsRead,
    setPreferences,
    preferences,
  } = useAppStore();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setIsOpen((prev) => !prev);
      }
      if (e.key === "Escape") {
        setIsOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  const commands = [
    {
      id: "home",
      label: "Go to All Items",
      icon: <Home className="h-4 w-4" />,
      action: () => {
        setCurrentView("feed");
        setSelectedFeed(null);
        setSelectedCategory(null);
      },
    },
    {
      id: "bookmarks",
      label: "Go to Saved",
      icon: <Bookmark className="h-4 w-4" />,
      action: () => setCurrentView("bookmarks"),
    },
    {
      id: "search",
      label: "Search",
      icon: <Search className="h-4 w-4" />,
      action: () => setCurrentView("search"),
    },
    {
      id: "analytics",
      label: "Go to Analytics",
      icon: <BarChart3 className="h-4 w-4" />,
      action: () => setCurrentView("analytics"),
    },
    {
      id: "digest",
      label: "Go to Digest",
      icon: <Inbox className="h-4 w-4" />,
      action: () => setCurrentView("digest"),
    },
    {
      id: "mark-all-read",
      label: "Mark All as Read",
      icon: <CheckCircle2 className="h-4 w-4" />,
      action: () => markAllAsRead(),
    },
    {
      id: "layout-list",
      label: "Switch to List Layout",
      icon: <Layout className="h-4 w-4" />,
      action: () => setPreferences({ layout: "list" }),
    },
    {
      id: "layout-cards",
      label: "Switch to Card Layout",
      icon: <Layout className="h-4 w-4" />,
      action: () => setPreferences({ layout: "cards" }),
    },
    {
      id: "layout-magazine",
      label: "Switch to Magazine Layout",
      icon: <Layout className="h-4 w-4" />,
      action: () => setPreferences({ layout: "magazine" }),
    },
    ...categories.map((cat) => ({
      id: `cat-${cat.id}`,
      label: `Go to ${cat.name}`,
      icon: <Rss className="h-4 w-4" />,
      action: () => {
        setSelectedCategory(cat.id);
        setCurrentView("feed");
      },
    })),
    ...feeds.map((feed) => ({
      id: `feed-${feed.id}`,
      label: `Go to ${feed.title}`,
      icon: <Rss className="h-4 w-4" />,
      action: () => {
        setSelectedFeed(feed.id);
        setCurrentView("feed");
      },
    })),
  ];

  const filtered = query
    ? commands.filter((cmd) =>
        cmd.label.toLowerCase().includes(query.toLowerCase())
      )
    : commands;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={() => setIsOpen(false)}
      />
      <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-full max-w-lg">
        <div className="bg-bg-surface rounded-xl border border-border shadow-lg overflow-hidden animate-fade-in">
          <div className="flex items-center gap-3 px-4 h-12 border-b border-border">
            <Search className="h-4 w-4 text-text-tertiary shrink-0" />
            <input
              ref={inputRef}
              type="text"
              placeholder="Type a command..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 bg-transparent text-sm text-text-primary placeholder:text-text-tertiary focus:outline-none"
            />
            <kbd className="text-xs text-text-tertiary bg-bg-tertiary px-1.5 py-0.5 rounded">
              ESC
            </kbd>
          </div>
          <div className="max-h-80 overflow-y-auto py-2">
            {filtered.map((cmd) => (
              <button
                key={cmd.id}
                onClick={() => {
                  cmd.action();
                  setIsOpen(false);
                  setQuery("");
                }}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-text-secondary hover:bg-bg-tertiary hover:text-text-primary transition-colors"
              >
                {cmd.icon}
                <span>{cmd.label}</span>
              </button>
            ))}
            {filtered.length === 0 && (
              <p className="text-center text-sm text-text-tertiary py-8">
                No commands found
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
