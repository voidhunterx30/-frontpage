"use client";

import Link from "next/link";
import { useState } from "react";
import {
  Rss,
  Bookmark,
  Search,
  Settings,
  BarChart3,
  ChevronDown,
  ChevronRight,
  Plus,
  Home,
  Zap,
  Menu,
  X,
  CheckCircle2,
  RefreshCw,
  Inbox,
} from "lucide-react";
import { cn, getFaviconUrl } from "@/lib/utils";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui";
import { ThemeToggle } from "@/components/theme-toggle";

export function Sidebar() {
  const {
    feeds,
    categories,
    selectedFeedId,
    selectedCategoryId,
    sidebarOpen,
    isGuest,
    currentView,
    setSelectedFeed,
    setSelectedCategory,
    setSidebarOpen,
    setCurrentView,
    getUnreadCount,
    markAllAsRead,
  } = useAppStore();

  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [showAddFeed, setShowAddFeed] = useState(false);
  const totalUnread = getUnreadCount();

  const toggleCategory = (catId: string) => {
    const next = new Set(expandedCategories);
    if (next.has(catId)) next.delete(catId);
    else next.add(catId);
    setExpandedCategories(next);
  };

  const feedsByCategory = categories.map((cat) => ({
    ...cat,
    feeds: feeds.filter((f) => f.category_id === cat.id),
  }));

  const uncategorizedFeeds = feeds.filter((f) => !f.category_id);

  return (
    <>
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed top-3 left-3 z-50 h-9 w-9 rounded-lg bg-bg-surface border border-border flex items-center justify-center lg:hidden shadow-md"
      >
        {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
      </button>

      <aside
        className={cn(
          "fixed top-0 left-0 z-40 h-full w-[260px] bg-bg-secondary border-r border-border flex flex-col transition-transform duration-200 lg:translate-x-0 lg:static lg:z-auto",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex items-center gap-2 px-4 h-14 border-b border-border shrink-0">
          <Zap className="h-5 w-5 text-accent" />
          <span className="text-base font-semibold text-text-primary">Frontpage</span>
          <div className="ml-auto flex items-center gap-1">
            <ThemeToggle />
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-2 px-2">
          <div className="space-y-0.5">
            <NavItem
              icon={<Home className="h-4 w-4" />}
              label="All Items"
              count={totalUnread}
              active={currentView === "feed" && !selectedFeedId && !selectedCategoryId}
              onClick={() => {
                setSelectedFeed(null);
                setSelectedCategory(null);
                setCurrentView("feed");
              }}
            />
            <NavItem
              icon={<Bookmark className="h-4 w-4" />}
              label="Saved"
              active={currentView === "bookmarks"}
              onClick={() => setCurrentView("bookmarks")}
            />
            <NavItem
              icon={<Search className="h-4 w-4" />}
              label="Search"
              active={currentView === "search"}
              onClick={() => setCurrentView("search")}
            />
            <NavItem
              icon={<BarChart3 className="h-4 w-4" />}
              label="Analytics"
              active={currentView === "analytics"}
              onClick={() => setCurrentView("analytics")}
            />
            <NavItem
              icon={<Inbox className="h-4 w-4" />}
              label="Digest"
              active={currentView === "digest"}
              onClick={() => setCurrentView("digest")}
            />
          </div>

          <div className="mt-4 mb-2 px-3 flex items-center justify-between">
            <span className="text-xs font-medium text-text-tertiary uppercase tracking-wider">
              Categories
            </span>
            {!isGuest && (
              <button
                onClick={() => setShowAddFeed(true)}
                className="h-5 w-5 rounded flex items-center justify-center text-text-tertiary hover:text-accent hover:bg-accent-subtle transition-colors"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <div className="space-y-0.5">
            {feedsByCategory.map((cat) => (
              <div key={cat.id}>
                <button
                  onClick={() => toggleCategory(cat.id)}
                  className={cn(
                    "w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors group",
                    selectedCategoryId === cat.id
                      ? "bg-accent-subtle text-accent"
                      : "text-text-secondary hover:bg-bg-tertiary hover:text-text-primary"
                  )}
                >
                  {expandedCategories.has(cat.id) ? (
                    <ChevronDown className="h-3.5 w-3.5 shrink-0" />
                  ) : (
                    <ChevronRight className="h-3.5 w-3.5 shrink-0" />
                  )}
                  <span className="truncate flex-1 text-left">{cat.name}</span>
                  {getUnreadCount(undefined, cat.id) > 0 && (
                    <span className="text-xs text-text-tertiary">
                      {getUnreadCount(undefined, cat.id)}
                    </span>
                  )}
                </button>

                {expandedCategories.has(cat.id) && (
                  <div className="ml-4 space-y-0.5">
                    {cat.feeds.map((feed) => (
                      <button
                        key={feed.id}
                        onClick={() => {
                          setSelectedFeed(feed.id);
                          setCurrentView("feed");
                        }}
                        className={cn(
                          "w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors",
                          selectedFeedId === feed.id
                            ? "bg-accent-subtle text-accent"
                            : "text-text-secondary hover:bg-bg-tertiary hover:text-text-primary"
                        )}
                      >
                        {feed.favicon_url ? (
                          <img
                            src={feed.favicon_url}
                            alt=""
                            className="h-3.5 w-3.5 rounded-sm"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = "none";
                            }}
                          />
                        ) : (
                          <Rss className="h-3.5 w-3.5 shrink-0" />
                        )}
                        <span className="truncate flex-1 text-left">
                          {feed.custom_title || feed.title}
                        </span>
                        {getUnreadCount(feed.id) > 0 && (
                          <span className="text-xs text-text-tertiary">
                            {getUnreadCount(feed.id)}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {uncategorizedFeeds.length > 0 && (
              <div>
                <button
                  onClick={() => toggleCategory("uncategorized")}
                  className="w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm text-text-secondary hover:bg-bg-tertiary hover:text-text-primary transition-colors"
                >
                  {expandedCategories.has("uncategorized") ? (
                    <ChevronDown className="h-3.5 w-3.5 shrink-0" />
                  ) : (
                    <ChevronRight className="h-3.5 w-3.5 shrink-0" />
                  )}
                  <span className="truncate flex-1 text-left">Uncategorized</span>
                </button>
                {expandedCategories.has("uncategorized") && (
                  <div className="ml-4 space-y-0.5">
                    {uncategorizedFeeds.map((feed) => (
                      <button
                        key={feed.id}
                        onClick={() => setSelectedFeed(feed.id)}
                        className={cn(
                          "w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors",
                          selectedFeedId === feed.id
                            ? "bg-accent-subtle text-accent"
                            : "text-text-secondary hover:bg-bg-tertiary hover:text-text-primary"
                        )}
                      >
                        <Rss className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate flex-1 text-left">
                          {feed.custom_title || feed.title}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </nav>

        <div className="p-3 border-t border-border shrink-0">
          {isGuest ? (
            <div className="space-y-2">
              <p className="text-xs text-text-tertiary text-center">
                Sign up to save your feeds
              </p>
              <Link href="/auth/signup">
                <Button variant="primary" size="sm" className="w-full">
                  Sign Up
                </Button>
              </Link>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCurrentView("settings")}
                className="flex-1 justify-start"
              >
                <Settings className="h-4 w-4" />
                Settings
              </Button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}

function NavItem({
  icon,
  label,
  count,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  count?: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors",
        active
          ? "bg-accent-subtle text-accent font-medium"
          : "text-text-secondary hover:bg-bg-tertiary hover:text-text-primary"
      )}
    >
      {icon}
      <span className="flex-1 text-left">{label}</span>
      {count !== undefined && count > 0 && (
        <span
          className={cn(
            "text-xs font-medium px-1.5 py-0.5 rounded-full min-w-[20px] text-center",
            active ? "bg-accent/20 text-accent" : "bg-bg-tertiary text-text-tertiary"
          )}
        >
          {count > 99 ? "99+" : count}
        </span>
      )}
    </button>
  );
}
