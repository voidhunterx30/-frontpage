"use client";

import { cn, timeAgo, shortDate, stripHtml, truncate, getFaviconUrl } from "@/lib/utils";
import { useAppStore } from "@/lib/store";
import { Bookmark, BookmarkCheck, ExternalLink, Clock, MoreHorizontal } from "lucide-react";
import type { FeedItem as FeedItemType, Feed } from "@/lib/types";
import { useState } from "react";

interface FeedItemProps {
  item: FeedItemType;
  feed?: Feed;
  layout: "list" | "cards" | "magazine";
  isSelected?: boolean;
  onClick?: () => void;
}

export function FeedItemCard({ item, feed, layout, isSelected, onClick }: FeedItemProps) {
  const { markAsRead, toggleBookmark, feeds } = useAppStore();
  const [showMenu, setShowMenu] = useState(false);

  const feedData = feed || feeds.find((f) => f.id === item.feed_id);
  const faviconUrl = feedData?.favicon_url || getFaviconUrl(item.url || "");
  const excerpt = item.description ? stripHtml(item.description) : "";
  const hasImage = item.image_url && layout !== "list";

  const handleClick = () => {
    if (!item.is_read) {
      markAsRead(item.id);
    }
    onClick?.();
  };

  if (layout === "cards") {
    return (
      <article
        onClick={handleClick}
        className={cn(
          "group relative rounded-xl border p-4 transition-all duration-150 cursor-pointer",
          isSelected
            ? "border-accent bg-accent-subtle/50 shadow-md"
            : "border-border hover:border-border/80 hover:shadow-sm bg-bg-surface",
          !item.is_read && "border-l-2 border-l-unread"
        )}
      >
        <div className="flex items-center gap-2 mb-2">
          {faviconUrl && (
            <img src={faviconUrl} alt="" className="h-4 w-4 rounded-sm shrink-0" />
          )}
          <span className="text-xs text-text-tertiary truncate">
            {feedData?.title || "Unknown"}
          </span>
          <span className="text-xs text-text-tertiary ml-auto shrink-0">
            {shortDate(item.published_at)}
          </span>
        </div>

        <h3
          className={cn(
            "text-sm font-medium leading-snug mb-1.5 line-clamp-2",
            item.is_read ? "text-text-secondary" : "text-text-primary"
          )}
        >
          {item.title}
        </h3>

        {excerpt && (
          <p className="text-xs text-text-tertiary leading-relaxed line-clamp-3 mb-3">
            {truncate(excerpt, 150)}
          </p>
        )}

        {hasImage && (
          <div className="mt-2 rounded-lg overflow-hidden bg-bg-tertiary">
            <img
              src={item.image_url!}
              alt=""
              className="w-full h-32 object-cover"
              loading="lazy"
            />
          </div>
        )}

        <div className="flex items-center gap-1 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleBookmark(item.id);
            }}
            className="h-7 w-7 rounded-md flex items-center justify-center hover:bg-bg-tertiary transition-colors"
          >
            {item.is_bookmarked ? (
              <BookmarkCheck className="h-3.5 w-3.5 text-accent" />
            ) : (
              <Bookmark className="h-3.5 w-3.5 text-text-tertiary" />
            )}
          </button>
          <a
            href={item.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="h-7 w-7 rounded-md flex items-center justify-center hover:bg-bg-tertiary transition-colors"
          >
            <ExternalLink className="h-3.5 w-3.5 text-text-tertiary" />
          </a>
        </div>
      </article>
    );
  }

  if (layout === "magazine") {
    return (
      <article
        onClick={handleClick}
        className={cn(
          "group relative flex gap-4 p-4 rounded-xl border transition-all duration-150 cursor-pointer",
          isSelected
            ? "border-accent bg-accent-subtle/50"
            : "border-border hover:border-border/80 hover:shadow-sm bg-bg-surface",
          !item.is_read && "border-l-2 border-l-unread"
        )}
      >
        {hasImage && (
          <div className="w-32 h-24 rounded-lg overflow-hidden bg-bg-tertiary shrink-0">
            <img
              src={item.image_url!}
              alt=""
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>
        )}

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            {faviconUrl && (
              <img src={faviconUrl} alt="" className="h-3.5 w-3.5 rounded-sm shrink-0" />
            )}
            <span className="text-xs text-text-tertiary truncate">
              {feedData?.title || "Unknown"}
            </span>
            <span className="text-xs text-text-tertiary">·</span>
            <span className="text-xs text-text-tertiary shrink-0">
              {timeAgo(item.published_at)}
            </span>
          </div>

          <h3
            className={cn(
              "text-sm font-medium leading-snug mb-1 line-clamp-2",
              item.is_read ? "text-text-secondary" : "text-text-primary"
            )}
          >
            {item.title}
          </h3>

          {excerpt && (
            <p className="text-xs text-text-tertiary leading-relaxed line-clamp-2">
              {truncate(excerpt, 120)}
            </p>
          )}
        </div>

        <div className="flex flex-col items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleBookmark(item.id);
            }}
            className="h-7 w-7 rounded-md flex items-center justify-center hover:bg-bg-tertiary transition-colors"
          >
            {item.is_bookmarked ? (
              <BookmarkCheck className="h-3.5 w-3.5 text-accent" />
            ) : (
              <Bookmark className="h-3.5 w-3.5 text-text-tertiary" />
            )}
          </button>
          <a
            href={item.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="h-7 w-7 rounded-md flex items-center justify-center hover:bg-bg-tertiary transition-colors"
          >
            <ExternalLink className="h-3.5 w-3.5 text-text-tertiary" />
          </a>
        </div>
      </article>
    );
  }

  return (
    <article
      onClick={handleClick}
      className={cn(
        "group flex items-start gap-3 px-4 py-3 border-b border-border-subtle transition-all duration-100 cursor-pointer",
        isSelected && "bg-accent-subtle/50",
        !item.is_read && "bg-bg-surface",
        item.is_read && "opacity-70 hover:opacity-100"
      )}
    >
      {!item.is_read && (
        <div className="h-2 w-2 rounded-full bg-unread shrink-0 mt-2" />
      )}
      {item.is_read && <div className="w-2 shrink-0" />}

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          {faviconUrl && (
            <img src={faviconUrl} alt="" className="h-3.5 w-3.5 rounded-sm shrink-0" />
          )}
          <span className="text-xs font-medium text-text-secondary truncate">
            {feedData?.title || "Unknown"}
          </span>
          <span className="text-xs text-text-tertiary shrink-0">
            {timeAgo(item.published_at)}
          </span>
        </div>

        <h3
          className={cn(
            "text-sm leading-snug line-clamp-1",
            item.is_read ? "text-text-secondary" : "text-text-primary font-medium"
          )}
        >
          {item.title}
        </h3>

        {excerpt && (
          <p className="text-xs text-text-tertiary mt-0.5 line-clamp-1">
            {truncate(excerpt, 100)}
          </p>
        )}
      </div>

      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleBookmark(item.id);
          }}
          className="h-7 w-7 rounded-md flex items-center justify-center hover:bg-bg-tertiary transition-colors"
        >
          {item.is_bookmarked ? (
            <BookmarkCheck className="h-3.5 w-3.5 text-accent" />
          ) : (
            <Bookmark className="h-3.5 w-3.5 text-text-tertiary" />
          )}
        </button>
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="h-7 w-7 rounded-md flex items-center justify-center hover:bg-bg-tertiary transition-colors"
        >
          <ExternalLink className="h-3.5 w-3.5 text-text-tertiary" />
        </a>
      </div>
    </article>
  );
}

export function FeedItemSkeleton({ layout }: { layout: "list" | "cards" | "magazine" }) {
  if (layout === "cards") {
    return (
      <div className="rounded-xl border border-border p-4 space-y-3">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 skeleton rounded-sm" />
          <div className="h-3 w-20 skeleton" />
          <div className="h-3 w-12 skeleton ml-auto" />
        </div>
        <div className="h-4 w-3/4 skeleton" />
        <div className="h-3 w-full skeleton" />
        <div className="h-3 w-2/3 skeleton" />
      </div>
    );
  }

  return (
    <div className="flex items-start gap-3 px-4 py-3 border-b border-border-subtle">
      <div className="h-2 w-2 rounded-full skeleton shrink-0 mt-2" />
      <div className="flex-1 space-y-1.5">
        <div className="flex items-center gap-2">
          <div className="h-3 w-16 skeleton" />
          <div className="h-3 w-12 skeleton" />
        </div>
        <div className="h-3.5 w-3/4 skeleton" />
        <div className="h-3 w-1/2 skeleton" />
      </div>
    </div>
  );
}
