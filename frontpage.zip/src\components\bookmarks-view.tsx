"use client";

import { useAppStore } from "@/lib/store";
import { FeedItemCard } from "@/components/feed-item";
import { Bookmark } from "lucide-react";

export function BookmarksView() {
  const { items, preferences } = useAppStore();
  const bookmarked = items.filter((i) => i.is_bookmarked);

  if (bookmarked.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Bookmark className="h-12 w-12 text-text-tertiary mb-4" />
        <h2 className="text-lg font-semibold text-text-primary mb-1">
          No saved articles
        </h2>
        <p className="text-sm text-text-secondary">
          Bookmark articles to read them later
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-text-primary">Saved Articles</h1>
        <p className="text-sm text-text-secondary mt-0.5">
          {bookmarked.length} article{bookmarked.length !== 1 ? "s" : ""} saved
        </p>
      </div>
      <div className="space-y-2">
        {bookmarked.map((item) => (
          <FeedItemCard key={item.id} item={item} layout={preferences.layout} />
        ))}
      </div>
    </div>
  );
}
