import { NextResponse } from "next/server";
import { fetchAndParseFeed } from "@/lib/feed-parser";
import { getFaviconUrl } from "@/lib/utils";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { url, category_id, custom_title } = body;

    if (!url) {
      return NextResponse.json({ error: "Feed URL is required" }, { status: 400 });
    }

    let parsed;
    try {
      parsed = await fetchAndParseFeed(url);
    } catch (err) {
      return NextResponse.json(
        { error: `Failed to parse feed: ${err instanceof Error ? err.message : "Unknown error"}` },
        { status: 400 }
      );
    }

    const feed = {
      id: crypto.randomUUID(),
      user_id: "local",
      title: parsed.title,
      feed_url: url,
      site_url: parsed.siteUrl,
      description: parsed.description,
      favicon_url: getFaviconUrl(parsed.siteUrl || url),
      category_id: category_id || null,
      custom_title: custom_title || undefined,
      last_fetched_at: new Date().toISOString(),
      last_error: null,
      health: "active" as const,
      created_at: new Date().toISOString(),
    };

    return NextResponse.json({ feed, items: parsed.items });
  } catch (error) {
    console.error("Feed API error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({ message: "Use POST to add a feed" });
}
