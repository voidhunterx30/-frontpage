export interface OpmlOutline {
  _text?: string;
  _title?: string;
  _type?: string;
  _xmlUrl?: string;
  _htmlUrl?: string;
  outline?: OpmlOutline[];
}

export interface OpmlFeed {
  title: string;
  feedUrl: string;
  siteUrl: string;
  category: string;
}

export function parseOpml(xml: string): OpmlFeed[] {
  const feeds: OpmlFeed[] = [];
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, "text/xml");

  const body = doc.querySelector("body");
  if (!body) return feeds;

  function processOutline(outline: Element, category: string) {
    const xmlUrl = outline.getAttribute("xmlUrl");
    const title = outline.getAttribute("title") || outline.getAttribute("text") || "Untitled";
    const htmlUrl = outline.getAttribute("htmlUrl") || "";

    if (xmlUrl) {
      feeds.push({
        title,
        feedUrl: xmlUrl,
        siteUrl: htmlUrl,
        category,
      });
    }

    const children = outline.querySelectorAll(":scope > outline");
    children.forEach((child) => {
      const childCategory = child.getAttribute("title") || child.getAttribute("text") || category;
      processOutline(child, childCategory);
    });
  }

  const topOutlines = body.querySelectorAll(":scope > outline");
  topOutlines.forEach((outline) => {
    processOutline(outline, "Imported");
  });

  return feeds;
}

export function generateOpml(
  feeds: { title: string; feed_url: string; site_url: string; category?: string }[]
): string {
  const categories = new Map<string, typeof feeds>();

  feeds.forEach((feed) => {
    const cat = feed.category || "Uncategorized";
    if (!categories.has(cat)) categories.set(cat, []);
    categories.get(cat)!.push(feed);
  });

  let opml = `<?xml version="1.0" encoding="UTF-8"?>
<opml version="2.0">
  <head>
    <title>Frontpage Subscriptions</title>
    <dateCreated>${new Date().toUTCString()}</dateCreated>
  </head>
  <body>
`;

  categories.forEach((catFeeds, catName) => {
    opml += `    <outline text="${escapeXml(catName)}" title="${escapeXml(catName)}">\n`;
    catFeeds.forEach((feed) => {
      opml += `      <outline type="rss" text="${escapeXml(feed.title)}" title="${escapeXml(feed.title)}" xmlUrl="${escapeXml(feed.feed_url)}" htmlUrl="${escapeXml(feed.site_url)}" />\n`;
    });
    opml += `    </outline>\n`;
  });

  opml += `  </body>
</opml>`;

  return opml;
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

export function downloadOpml(content: string, filename: string = "frontpage-feeds.opml") {
  const blob = new Blob([content], { type: "text/xml" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
