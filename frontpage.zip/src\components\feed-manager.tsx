"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { Button, Input } from "@/components/ui";
import {
  X,
  Plus,
  CheckCircle2,
  AlertCircle,
  Loader2,
  FolderPlus,
  Trash2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Feed } from "@/lib/types";

export function FeedManager() {
  const {
    feeds,
    categories,
    setFeeds,
    setCategories,
    addCategory,
    deleteCategory,
    isGuest,
  } = useAppStore();

  const [showAddFeed, setShowAddFeed] = useState(false);
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [feedUrl, setFeedUrl] = useState("");
  const [feedCategory, setFeedCategory] = useState("");
  const [customTitle, setCustomTitle] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [addResult, setAddResult] = useState<{
    success: boolean;
    message: string;
  } | null>(null);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [editingFeed, setEditingFeed] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const handleAddFeed = async () => {
    if (!feedUrl.trim()) return;
    setIsAdding(true);
    setAddResult(null);

    try {
      const res = await fetch("/api/feeds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: feedUrl.trim(),
          category_id: feedCategory || null,
          custom_title: customTitle.trim() || undefined,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        setAddResult({ success: true, message: `Added "${data.feed.title}" successfully!` });
        setFeeds([...feeds, data.feed]);
        setFeedUrl("");
        setCustomTitle("");
        setTimeout(() => {
          setShowAddFeed(false);
          setAddResult(null);
        }, 2000);
      } else {
        setAddResult({ success: false, message: data.error || "Failed to add feed" });
      }
    } catch {
      setAddResult({ success: false, message: "Network error. Please try again." });
    } finally {
      setIsAdding(false);
    }
  };

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return;
    const newCat = {
      id: crypto.randomUUID(),
      user_id: "local",
      name: newCategoryName.trim(),
      order_index: categories.length,
      created_at: new Date().toISOString(),
    };
    addCategory(newCat);
    setNewCategoryName("");
    setShowAddCategory(false);
  };

  const handleDeleteFeed = (feedId: string) => {
    setFeeds(feeds.filter((f) => f.id !== feedId));
    setDeleteConfirm(null);
  };

  const handleDeleteCategory = (catId: string) => {
    deleteCategory(catId);
  };

  const handleUpdateFeedCategory = (feedId: string, categoryId: string) => {
    setFeeds(
      feeds.map((f) =>
        f.id === feedId ? { ...f, category_id: categoryId || null } : f
      )
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-text-primary">Feed Management</h2>
          <p className="text-sm text-text-secondary mt-0.5">
            {feeds.length} feeds across {categories.length} categories
          </p>
        </div>
        {!isGuest && (
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setShowAddCategory(true)}
            >
              <FolderPlus className="h-3.5 w-3.5" />
              Category
            </Button>
            <Button variant="primary" size="sm" onClick={() => setShowAddFeed(true)}>
              <Plus className="h-3.5 w-3.5" />
              Add Feed
            </Button>
          </div>
        )}
      </div>

      {showAddCategory && (
        <div className="p-4 rounded-xl border border-border bg-bg-surface animate-fade-in">
          <h3 className="text-sm font-medium text-text-primary mb-3">New Category</h3>
          <div className="flex gap-2">
            <Input
              placeholder="Category name..."
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddCategory()}
              className="flex-1"
              autoFocus
            />
            <Button variant="primary" size="sm" onClick={handleAddCategory}>
              Add
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setShowAddCategory(false);
                setNewCategoryName("");
              }}
            >
              Cancel
            </Button>
          </div>
        </div>
      )}

      {showAddFeed && (
        <div className="p-4 rounded-xl border border-border bg-bg-surface animate-fade-in">
          <h3 className="text-sm font-medium text-text-primary mb-3">Add Feed</h3>
          <div className="space-y-3">
            <Input
              placeholder="RSS or Atom feed URL..."
              value={feedUrl}
              onChange={(e) => setFeedUrl(e.target.value)}
              autoFocus
            />
            <Input
              placeholder="Custom title (optional)"
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
            />
            <select
              value={feedCategory}
              onChange={(e) => setFeedCategory(e.target.value)}
              className="w-full h-9 rounded-lg border bg-bg-primary px-3 text-sm text-text-primary border-border focus:border-accent focus:outline-none"
            >
              <option value="">No category</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>

            {addResult && (
              <div
                className={cn(
                  "flex items-center gap-2 text-sm p-2 rounded-lg",
                  addResult.success
                    ? "bg-success/10 text-success"
                    : "bg-error/10 text-error"
                )}
              >
                {addResult.success ? (
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                ) : (
                  <AlertCircle className="h-4 w-4 shrink-0" />
                )}
                {addResult.message}
              </div>
            )}

            <div className="flex gap-2">
              <Button
                variant="primary"
                size="sm"
                onClick={handleAddFeed}
                disabled={isAdding || !feedUrl.trim()}
              >
                {isAdding ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Plus className="h-3.5 w-3.5" />
                )}
                {isAdding ? "Adding..." : "Add Feed"}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setShowAddFeed(false);
                  setFeedUrl("");
                  setCustomTitle("");
                  setAddResult(null);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {categories.map((cat) => (
          <div key={cat.id} className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-sm font-medium text-text-primary">{cat.name}</h3>
              {!isGuest && (
                <button
                  onClick={() => handleDeleteCategory(cat.id)}
                  className="text-text-tertiary hover:text-error transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            <div className="space-y-1">
              {feeds
                .filter((f) => f.category_id === cat.id)
                .map((feed) => (
                  <FeedRow
                    key={feed.id}
                    feed={feed}
                    categories={categories}
                    isGuest={isGuest}
                    editingFeed={editingFeed}
                    deleteConfirm={deleteConfirm}
                    setEditingFeed={setEditingFeed}
                    setDeleteConfirm={setDeleteConfirm}
                    onUpdateCategory={(catId) =>
                      handleUpdateFeedCategory(feed.id, catId)
                    }
                    onDelete={() => handleDeleteFeed(feed.id)}
                  />
                ))}
              {feeds.filter((f) => f.category_id === cat.id).length === 0 && (
                <p className="text-xs text-text-tertiary px-3 py-2">
                  No feeds in this category
                </p>
              )}
            </div>
          </div>
        ))}

        {feeds.filter((f) => !f.category_id).length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-text-primary px-1">Uncategorized</h3>
            <div className="space-y-1">
              {feeds
                .filter((f) => !f.category_id)
                .map((feed) => (
                  <FeedRow
                    key={feed.id}
                    feed={feed}
                    categories={categories}
                    isGuest={isGuest}
                    editingFeed={editingFeed}
                    deleteConfirm={deleteConfirm}
                    setEditingFeed={setEditingFeed}
                    setDeleteConfirm={setDeleteConfirm}
                    onUpdateCategory={(catId) =>
                      handleUpdateFeedCategory(feed.id, catId)
                    }
                    onDelete={() => handleDeleteFeed(feed.id)}
                  />
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function FeedRow({
  feed,
  categories,
  isGuest,
  editingFeed,
  deleteConfirm,
  setEditingFeed,
  setDeleteConfirm,
  onUpdateCategory,
  onDelete,
}: {
  feed: Feed;
  categories: { id: string; name: string }[];
  isGuest: boolean;
  editingFeed: string | null;
  deleteConfirm: string | null;
  setEditingFeed: (id: string | null) => void;
  setDeleteConfirm: (id: string | null) => void;
  onUpdateCategory: (catId: string) => void;
  onDelete: () => void;
}) {
  const [editCat, setEditCat] = useState(feed.category_id || "");

  const healthColor = {
    active: "bg-success",
    stale: "bg-warning",
    error: "bg-error",
  }[feed.health] || "bg-gray-400";

  return (
    <div className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-bg-tertiary transition-colors group">
      {feed.favicon_url ? (
        <img
          src={feed.favicon_url}
          alt=""
          className="h-5 w-5 rounded-sm shrink-0"
          onError={(e) => {
            (e.target as HTMLImageElement).style.display = "none";
          }}
        />
      ) : (
        <div className="h-5 w-5 rounded-sm bg-bg-tertiary flex items-center justify-center shrink-0">
          <Rss className="h-3 w-3 text-text-tertiary" />
        </div>
      )}

      <div className={cn("h-2 w-2 rounded-full shrink-0", healthColor)} title={`Status: ${feed.health}`} />

      <div className="flex-1 min-w-0">
        <p className="text-sm text-text-primary truncate">
          {feed.custom_title || feed.title}
        </p>
        <p className="text-xs text-text-tertiary truncate">{feed.feed_url}</p>
      </div>

      {!isGuest && (
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <select
            value={editCat}
            onChange={(e) => {
              setEditCat(e.target.value);
              onUpdateCategory(e.target.value);
            }}
            className="h-7 text-xs rounded border border-border bg-bg-primary px-1 text-text-secondary"
          >
            <option value="">None</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {deleteConfirm === feed.id ? (
            <div className="flex items-center gap-1">
              <Button variant="danger" size="sm" onClick={onDelete}>
                Delete
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setDeleteConfirm(null)}
              >
                Cancel
              </Button>
            </div>
          ) : (
            <button
              onClick={() => setDeleteConfirm(feed.id)}
              className="h-7 w-7 rounded-md flex items-center justify-center text-text-tertiary hover:text-error hover:bg-error/10 transition-colors"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function Rss({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="5" cy="19" r="1.5" fill="currentColor" />
      <path d="M2 10a7 7 0 0 1 7 7" strokeLinecap="round" />
      <path d="MM2 4a13 13 0 0 1 13 13" strokeLinecap="round" />
    </svg>
  );
}
