"use client";

import { useState, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/store";
import { FeedItemCard } from "@/components/feed-item";
import { Input, Spinner } from "@/components/ui";
import { Search as SearchIcon, X, Filter } from "lucide-react";
import { cn, stripHtml, truncate } from "@/lib/utils";

export function SearchView() {
  const { items, feeds, preferences, setCurrentView } = useAppStore();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<typeof items>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedFeedFilter, setSelectedFeedFilter] = useState<string>("");
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("frontpage_recent_searches");
    if (saved) setRecentSearches(JSON.parse(saved));
  }, []);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    const timer = setTimeout(() => {
      const lower = query.toLowerCase();
      let filtered = items.filter((item) => {
        const titleMatch = item.title.toLowerCase().includes(lower);
        const descMatch = item.description?.toLowerCase().includes(lower);
        const contentMatch = item.content?.toLowerCase().includes(lower);
        return titleMatch || descMatch || contentMatch;
      });

      if (selectedFeedFilter) {
        filtered = filtered.filter((item) => item.feed_id === selectedFeedFilter);
      }

      setResults(filtered);
      setIsSearching(false);
    }, 200);

    return () => clearTimeout(timer);
  }, [query, items, selectedFeedFilter]);

  const handleSearch = (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    const updated = [searchQuery, ...recentSearches.filter((s) => s !== searchQuery)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem("frontpage_recent_searches", JSON.stringify(updated));
  };

  const clearRecent = () => {
    setRecentSearches([]);
    localStorage.removeItem("frontpage_recent_searches");
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="relative mb-6">
        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-tertiary" />
        <input
          ref={inputRef}
          type="text"
          placeholder="Search articles..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch(query)}
          className="w-full h-11 rounded-xl border bg-bg-surface pl-10 pr-10 text-base text-text-primary placeholder:text-text-tertiary border-border focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all"
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 rounded-full bg-bg-tertiary flex items-center justify-center hover:bg-border transition-colors"
          >
            <X className="h-3 w-3 text-text-secondary" />
          </button>
        )}
      </div>

      <div className="flex items-center gap-2 mb-4">
        <Filter className="h-3.5 w-3.5 text-text-tertiary" />
        <select
          value={selectedFeedFilter}
          onChange={(e) => setSelectedFeedFilter(e.target.value)}
          className="h-8 text-sm rounded-lg border border-border bg-bg-primary px-2 text-text-secondary focus:outline-none"
        >
          <option value="">All feeds</option>
          {feeds.map((f) => (
            <option key={f.id} value={f.id}>
              {f.title}
            </option>
          ))}
        </select>
        {selectedFeedFilter && (
          <button
            onClick={() => setSelectedFeedFilter("")}
            className="text-xs text-accent hover:text-accent-hover"
          >
            Clear filter
          </button>
        )}
      </div>

      {!query && recentSearches.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-medium text-text-tertiary uppercase tracking-wider">
              Recent Searches
            </h3>
            <button
              onClick={clearRecent}
              className="text-xs text-text-tertiary hover:text-error"
            >
              Clear
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map((search) => (
              <button
                key={search}
                onClick={() => {
                  setQuery(search);
                  handleSearch(search);
                }}
                className="px-3 py-1.5 rounded-lg bg-bg-tertiary text-sm text-text-secondary hover:bg-border transition-colors"
              >
                {search}
              </button>
            ))}
          </div>
        </div>
      )}

      {isSearching && (
        <div className="flex items-center justify-center py-12">
          <Spinner size="lg" />
        </div>
      )}

      {!isSearching && query && results.length === 0 && (
        <div className="text-center py-12">
          <SearchIcon className="h-10 w-10 text-text-tertiary mx-auto mb-3" />
          <h3 className="text-base font-medium text-text-primary mb-1">
            No results found
          </h3>
          <p className="text-sm text-text-secondary">
            Try different keywords or check your spelling
          </p>
        </div>
      )}

      {!isSearching && results.length > 0 && (
        <div>
          <p className="text-sm text-text-secondary mb-3">
            {results.length} result{results.length !== 1 ? "s" : ""} found
          </p>
          <div className="space-y-2">
            {results.map((item) => (
              <SearchResultItem key={item.id} item={item} layout={preferences.layout} />
            ))}
          </div>
        </div>
      )}

      {!query && (
        <div className="text-center py-12">
          <SearchIcon className="h-10 w-10 text-text-tertiary mx-auto mb-3" />
          <h3 className="text-base font-medium text-text-primary mb-1">
            Search your feeds
          </h3>
          <p className="text-sm text-text-secondary">
            Find articles across all your subscriptions
          </p>
          <p className="text-xs text-text-tertiary mt-2">
            Press <kbd className="px-1.5 py-0.5 rounded bg-bg-tertiary text-text-secondary">/</kbd> to focus search from anywhere
          </p>
        </div>
      )}
    </div>
  );
}

function SearchResultItem({
  item,
  layout,
}: {
  item: any;
  layout: "list" | "cards" | "magazine";
}) {
  const { markAsRead } = useAppStore();
  const feed = useAppStore((s) => s.feeds.find((f) => f.id === item.feed_id));

  return (
    <div
      onClick={() => !item.is_read && markAsRead(item.id)}
      className="p-4 rounded-xl border border-border bg-bg-surface hover:border-border/80 hover:shadow-sm transition-all cursor-pointer"
    >
      <div className="flex items-center gap-2 mb-1.5">
        {feed?.favicon_url && (
          <img src={feed.favicon_url} alt="" className="h-3.5 w-3.5 rounded-sm" />
        )}
        <span className="text-xs text-text-tertiary">{feed?.title}</span>
        <span className="text-xs text-text-tertiary">·</span>
        <span className="text-xs text-text-tertiary">
          {new Date(item.published_at).toLocaleDateString()}
        </span>
      </div>
      <h3 className="text-sm font-medium text-text-primary mb-1">{item.title}</h3>
      {item.description && (
        <p className="text-xs text-text-secondary line-clamp-2">
          {truncate(stripHtml(item.description), 180)}
        </p>
      )}
    </div>
  );
}
