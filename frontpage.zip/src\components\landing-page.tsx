"use client";

import Link from "next/link";
import {
  Rss,
  BookOpen,
  Search,
  Layers,
  Sparkles,
  ArrowRight,
  Zap,
  Star,
} from "lucide-react";
import { Button } from "@/components/ui";

export function LandingPage() {
  return (
    <div className="min-h-screen bg-bg-primary">
      <header className="border-b border-border">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-accent" />
            <span className="text-lg font-semibold text-text-primary">Frontpage</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/signin">
              <Button variant="ghost" size="sm">
                Sign In
              </Button>
            </Link>
            <Link href="/auth/signup">
              <Button variant="primary" size="sm">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-accent/5 via-transparent to-transparent" />
          <div className="max-w-6xl mx-auto px-6 py-24 md:py-32 relative">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent-subtle text-accent text-sm font-medium mb-6">
                <Sparkles className="h-3.5 w-3.5" />
                Your personalized front page for tech content
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary leading-tight mb-6">
                Stop missing out on
                <br />
                <span className="text-accent">great content</span>
              </h1>

              <p className="text-lg md:text-xl text-text-secondary max-w-2xl mx-auto mb-10 leading-relaxed">
                frontpage is a modern feed reader that helps you stay on top of the content that matters most to you.
                 organize your feeds, read articles in a clean reader view, and never miss out on great content again.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/auth/signup">
                  <Button variant="primary" size="lg" className="min-w-[180px]">
                    Sign Up Free
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/guest">
                  <Button variant="secondary" size="lg" className="min-w-[180px]">
                    Try as Guest
                  </Button>
                </Link>
              </div>

              <p className="text-sm text-text-tertiary mt-6">
                No credit card required. Guest mode lets you explore instantly.
              </p>
            </div>
          </div>
        </section>

        <section className="border-t border-border bg-bg-secondary/50">
          <div className="max-w-6xl mx-auto px-6 py-20">
            <div className="text-center mb-14">
              <h2 className="text-2xl md:text-3xl font-semibold text-text-primary mb-3">
                Everything you need to stay informed
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto">
                A powerful feed reader designed for developers and designers who care
                about both content and craft.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FeatureCard
                icon={<Rss className="h-5 w-5" />}
                title="RSS & Atom Feeds"
                description="Add any RSS or Atom feed. We handle parsing, normalization, and error recovery automatically."
              />
              <FeatureCard
                icon={<Layers className="h-5 w-5" />}
                title="Smart Categories"
                description="Organize feeds by topic. Switch between list, card, and magazine layouts per your preference."
              />
              <FeatureCard
                icon={<BookOpen className="h-5 w-5" />}
                title="Reader View"
                description="Read full articles inline with clean typography. Navigate between articles without losing your place."
              />
              <FeatureCard
                icon={<Search className="h-5 w-5" />}
                title="Instant Search"
                description="Find anything across all your feeds with full-text search. Results appear as you type."
              />
              <FeatureCard
                icon={<Star className="h-5 w-5" />}
                title="Bookmarks"
                description="Save articles for later. Build your personal reading list that persists across sessions."
              />
              <FeatureCard
                icon={<Sparkles className="h-5 w-5" />}
                title="Reading Digest"
                description="Get a curated summary of what you missed. Never feel overwhelmed by your feeds again."
              />
            </div>
          </div>
        </section>

        <section className="border-t border-border">
          <div className="max-w-6xl mx-auto px-6 py-20">
            <div className="bg-bg-secondary rounded-2xl border border-border p-8 md:p-12 text-center">
              <h2 className="text-2xl md:text-3xl font-semibold text-text-primary mb-4">
                Ready to organize your reading?
              </h2>
              <p className="text-text-secondary max-w-lg mx-auto mb-8">
                Join developers and designers who use Frontpage to stay on top of
                the content that matters most.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/guest">
                  <Button variant="primary" size="lg">
                    Try as Guest
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/auth/signup">
                  <Button variant="secondary" size="lg">
                    Create Account
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-2 text-text-tertiary text-sm">
            <Zap className="h-4 w-4" />
            <span>Frontpage</span>
          </div>
          <p className="text-xs text-text-tertiary">
            A Frontend Mentor Product Challenge
          </p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="group p-6 rounded-xl border border-border bg-bg-surface hover:border-border/80 hover:shadow-md transition-all duration-200">
      <div className="h-10 w-10 rounded-lg bg-accent-subtle flex items-center justify-center text-accent mb-4">
        {icon}
      </div>
      <h3 className="text-base font-semibold text-text-primary mb-2">{title}</h3>
      <p className="text-sm text-text-secondary leading-relaxed">{description}</p>
    </div>
  );
}
