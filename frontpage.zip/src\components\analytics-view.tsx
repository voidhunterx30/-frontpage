"use client";

import { useAppStore } from "@/lib/store";
import { BarChart3, BookOpen, TrendingUp, Flame, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export function AnalyticsView() {
  const { items, feeds, categories } = useAppStore();

  const totalRead = items.filter((i) => i.is_read).length;
  const totalUnread = items.filter((i) => !i.is_read).length;
  const totalItems = items.length;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const readToday = items.filter(
    (i) => i.is_read && new Date(i.created_at) >= today
  ).length;

  const thisWeek = new Date();
  thisWeek.setDate(thisWeek.getDate() - 7);
  const readThisWeek = items.filter(
    (i) => i.is_read && new Date(i.created_at) >= thisWeek
  ).length;

  const bookmarks = items.filter((i) => i.is_bookmarked).length;

  const categoryStats = categories.map((cat) => {
    const catFeeds = feeds.filter((f) => f.category_id === cat.id);
    const catItems = items.filter((i) =>
      catFeeds.some((f) => f.id === i.feed_id)
    );
    return {
      name: cat.name,
      total: catItems.length,
      read: catItems.filter((i) => i.is_read).length,
    };
  });

  const feedStats = feeds
    .map((feed) => {
      const feedItems = items.filter((i) => i.feed_id === feed.id);
      return {
        name: feed.title,
        total: feedItems.length,
        read: feedItems.filter((i) => i.is_read).length,
      };
    })
    .sort((a, b) => b.total - a.total)
    .slice(0, 8);

  const healthStats = {
    active: feeds.filter((f) => f.health === "active").length,
    stale: feeds.filter((f) => f.health === "stale").length,
    error: feeds.filter((f) => f.health === "error").length,
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="mb-8">
        <h1 className="text-xl font-semibold text-text-primary">Reading Analytics</h1>
        <p className="text-sm text-text-secondary mt-0.5">
          Your reading habits at a glance
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatCard
          icon={<BookOpen className="h-4 w-4" />}
          label="Total Articles"
          value={totalItems}
        />
        <StatCard
          icon={<TrendingUp className="h-4 w-4" />}
          label="Read"
          value={totalRead}
          color="text-success"
        />
        <StatCard
          icon={<Flame className="h-4 w-4" />}
          label="Read Today"
          value={readToday}
          color="text-accent"
        />
        <StatCard
          icon={<Clock className="h-4 w-4" />}
          label="Unread"
          value={totalUnread}
          color="text-warning"
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">
            Categories
          </h2>
          <div className="space-y-3">
            {categoryStats.map((cat) => (
              <div key={cat.name}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-text-secondary">{cat.name}</span>
                  <span className="text-xs text-text-tertiary">
                    {cat.read}/{cat.total}
                  </span>
                </div>
                <div className="h-2 rounded-full bg-bg-tertiary overflow-hidden">
                  <div
                    className="h-full rounded-full bg-accent transition-all duration-500"
                    style={{
                      width: cat.total ? `${(cat.read / cat.total) * 100}%` : "0%",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">
            Top Feeds
          </h2>
          <div className="space-y-3">
            {feedStats.map((feed) => (
              <div key={feed.name}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-text-secondary truncate pr-2">
                    {feed.name}
                  </span>
                  <span className="text-xs text-text-tertiary shrink-0">
                    {feed.read}/{feed.total}
                  </span>
                </div>
                <div className="h-2 rounded-full bg-bg-tertiary overflow-hidden">
                  <div
                    className="h-full rounded-full bg-success transition-all duration-500"
                    style={{
                      width: feed.total
                        ? `${(feed.read / feed.total) * 100}%`
                        : "0%",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">
            Feed Health
          </h2>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-success">
                {healthStats.active}
              </div>
              <div className="text-xs text-text-tertiary">Active</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-warning">
                {healthStats.stale}
              </div>
              <div className="text-xs text-text-tertiary">Stale</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-error">
                {healthStats.error}
              </div>
              <div className="text-xs text-text-tertiary">Error</div>
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl border border-border bg-bg-surface">
          <h2 className="text-sm font-semibold text-text-primary mb-4">
            Summary
          </h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-text-secondary">This week</span>
              <span className="text-text-primary font-medium">
                {readThisWeek} articles
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Bookmarks</span>
              <span className="text-text-primary font-medium">{bookmarks}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Total feeds</span>
              <span className="text-text-primary font-medium">{feeds.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Read rate</span>
              <span className="text-text-primary font-medium">
                {totalItems ? Math.round((totalRead / totalItems) * 100) : 0}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  color = "text-text-primary",
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color?: string;
}) {
  return (
    <div className="p-4 rounded-xl border border-border bg-bg-surface">
      <div className="flex items-center gap-2 mb-2">
        <div className="h-8 w-8 rounded-lg bg-bg-tertiary flex items-center justify-center text-text-secondary">
          {icon}
        </div>
      </div>
      <div className={cn("text-2xl font-bold", color)}>{value}</div>
      <div className="text-xs text-text-tertiary mt-0.5">{label}</div>
    </div>
  );
}
