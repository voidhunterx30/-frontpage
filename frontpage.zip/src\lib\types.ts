export interface Feed {
  id: string;
  user_id: string;
  title: string;
  feed_url: string;
  site_url: string;
  description: string;
  favicon_url: string;
  category_id: string | null;
  last_fetched_at: string | null;
  last_error: string | null;
  health: "active" | "stale" | "error";
  created_at: string;
  custom_title?: string;
}

export interface FeedItem {
  id: string;
  feed_id: string;
  title: string;
  url: string;
  author: string | null;
  description: string | null;
  content: string | null;
  published_at: string;
  image_url: string | null;
  is_read: boolean;
  is_bookmarked: boolean;
  created_at: string;
}

export interface Category {
  id: string;
  user_id: string;
  name: string;
  order_index: number;
  created_at: string;
}

export interface UserPreferences {
  layout: "list" | "cards" | "magazine";
  theme: "light" | "dark" | "system";
  refresh_interval: number;
  show_read_items: boolean;
}

export interface GuestFeed {
  title: string;
  feedUrl: string;
  siteUrl: string;
  description: string;
  format: string;
  category: string;
}

export type FeedHealth = "active" | "stale" | "error";

export interface SearchResult {
  id: string;
  title: string;
  url: string;
  description: string | null;
  published_at: string;
  feed_title: string;
  feed_id: string;
  score: number;
}

export interface ReadingStats {
  articles_read: number;
  articles_today: number;
  articles_this_week: number;
  reading_streak: number;
  top_categories: { name: string; count: number }[];
  top_feeds: { name: string; count: number }[];
  daily_reads: { date: string; count: number }[];
}
